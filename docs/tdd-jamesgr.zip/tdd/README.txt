Unzip into <someDirectory>, resulting in
		<someDirectory>/makeAll.sh
		<someDirectory>/README.TXT
		<someDirectory>/CppUTest/
		<someDirectory>/TddInCppExercises1/
		<someDirectory>/TddInCppExercises2/
		<someDirectory>/TddInCppSolutions/

-----------------------      	
Unix/linux/cygwin users 
-----------------------
  % ./makeAll.sh
  
After make all, you only need to run make from the TddInCppExercises1 or
TddInCppExercises2 directories

 % cd TddInCppExercises1
 % make [all|clean] 
