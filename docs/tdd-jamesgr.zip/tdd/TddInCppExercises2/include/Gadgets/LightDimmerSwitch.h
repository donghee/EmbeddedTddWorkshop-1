//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_LightDimmerSwitch_H
#define D_LightDimmerSwitch_H

///////////////////////////////////////////////////////////////////////////////
//
//  LightDimmerSwitch is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class LightDimmerSwitch
  {
  public:
    explicit LightDimmerSwitch();
    virtual ~LightDimmerSwitch();

    virtual void AdjustTo(int percentOn) = 0;

  private:

    LightDimmerSwitch(const LightDimmerSwitch&);
    LightDimmerSwitch& operator=(const LightDimmerSwitch&);

  };

#endif  // D_LightDimmerSwitch_H
