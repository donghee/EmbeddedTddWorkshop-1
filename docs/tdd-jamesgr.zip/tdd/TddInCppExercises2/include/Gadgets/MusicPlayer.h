//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MusicPlayer_H
#define D_MusicPlayer_H

///////////////////////////////////////////////////////////////////////////////
//
//  MusicPlayer is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class MusicPlayer
  {
  public:
    explicit MusicPlayer();
    virtual ~MusicPlayer();

  private:

    MusicPlayer(const MusicPlayer&);
    MusicPlayer& operator=(const MusicPlayer&);

  };

#endif  // D_MusicPlayer_H
