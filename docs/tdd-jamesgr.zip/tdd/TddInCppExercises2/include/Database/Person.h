//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_Person_H
#define D_Person_H

///////////////////////////////////////////////////////////////////////////////
//
//  Person is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include <string>

class Person
{
public:
    explicit Person(std::string name, std::string eMailAddr,
            const Person* personToNotify);
    explicit Person(std::string name, std::string eMailAddr);

    virtual ~Person();

    std::string GetName() const;
    void SetName(std::string name);

    std::string GetEMailAddress() const;
    void SetEMailAddress(std::string eMailAddress);

    const Person* GetPersonToNotify() const;
    void SetPersonToNotify(const Person* personToNotify);

private:

    std::string name;
    std::string eMailAddress;
    const Person* personToNotify;

    Person(const Person&);
    Person& operator=(const Person&);
};

#endif  // D_Person_H
