//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_People_H
#define D_People_H

///////////////////////////////////////////////////////////////////////////////
//
//  People is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include "Person.h"
#include <map>
#include <string>

class People
{
    public:
        explicit People();
        virtual ~People();


        virtual const Person* GetAdmin()
        {
            return People::SGetAdmin();
        }

        virtual const Person* GetByRfid(std::string rfid)
        {
            return People::SGetByRfid(rfid);
        }

    private:
        static const Person* SGetAdmin();
        static const Person* SGetByRfid(std::string rfid);

        People(const People&);
        People& operator=(const People&);

};

class TestPeople : public People
{
    private:
        Person* _admin;

        typedef std::map<std::string, const Person*> Persons;
        Persons _persons;

    public:
        TestPeople()
            : _admin(0)
        {
        }

        virtual ~TestPeople()
        {
            delete _admin;
        }

        void SetAdmin(Person* p)
        {
            _admin = p;
        }

        virtual const Person* GetAdmin()
        {
            return _admin;
        }

        void SetByRfid(const std::string& rfid, const Person* p)
        {
            _persons[rfid] = p;
        }

        virtual const Person* GetByRfid(std::string rfid)
        {
            Persons::const_iterator iter = _persons.find(rfid);
            const Person* ret(0);

            if(iter != _persons.end())
            {
                ret = iter->second;
            }
            return ret;
        }
};

#endif  // D_People_H
