//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_EMail_H
#define D_EMail_H

///////////////////////////////////////////////////////////////////////////////
//
//  EMail is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include <string>

class EMail
{
public:
    explicit EMail(std::string address, std::string subject, std::string body);
    virtual ~EMail();

    bool Send();

    const std::string& GetAddress() const
    {
        return address;
    }

private:

    std::string address;
    std::string subject;
    std::string body;

    EMail(const EMail&);
    EMail& operator=(const EMail&);
};

#endif  // D_EMail_H
