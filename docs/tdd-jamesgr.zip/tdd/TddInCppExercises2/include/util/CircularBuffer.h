//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

/* Copyright (c) 2007, 2008
 * James Grenning All Rights Reserved
 * Renaissance Software Consulting, Inc
 * For use as a conference exercise only
 *
 * Contact info:
 * www.renaissancesoftware.net
 * www.renaissancesoftware.net/blog
 * james@renaissancesoftware.net
 */


#ifndef D_CircularBuffer_H
#define D_CircularBuffer_H
///////////////////////////////////////////////////////////////////////////////
//
//  CircularBuffer.h
//
//  CircularBuffer is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

#include <string>

class CircularBuffer
{
  public:
    explicit CircularBuffer(int capacity);
    virtual ~CircularBuffer();

    bool IsEmpty() const;
    bool IsFull() const;
    void Put(int);
    int Get();
    int Capacity() const;

  private:

	  int capacity;
	  int index;
	  int outdex;
	  int count;
	  int* values;

	  int NextDex(int dex) const;

    CircularBuffer(const CircularBuffer&);
    CircularBuffer& operator=(const CircularBuffer&);
};

class CircularBufferException
{
	public:
		CircularBufferException(std::string message)
		: message(message){}

		std::string Message(){return message;}

	private:
		std::string message;

};

#endif  // D_CircularBuffer_H
