//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_Logger_H
#define D_Logger_H

///////////////////////////////////////////////////////////////////////////////
//
//  Logger is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include <string>
#include <iosfwd>
#include <vector>


class Logger
  {
  public:
    explicit Logger(std::string name, int capacity);
    virtual ~Logger();

    int count() const;
    void print(std::ostream&) const;
    void log(const char *, ...);
    void clear();

  private:

     std::string name;
     int capacity;
     int index;
     std::vector<char*>* logBuffer;
     int logCount;

    Logger(const Logger&);
    Logger& operator=(const Logger&);

  };

#endif  // D_Logger_H
