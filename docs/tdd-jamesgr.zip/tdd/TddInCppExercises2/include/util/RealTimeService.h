//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_RealTimeService_H
#define D_RealTimeService_H

///////////////////////////////////////////////////////////////////////////////
//
//  RealTimeService is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include "TimeService.h"

struct Time;

class RealTimeService : public TimeService
  {

  public:

    explicit RealTimeService();
    virtual ~RealTimeService();

    virtual int GetMinute() const;
    virtual TimeService::Day GetDay() const ;
    virtual void WakePeriodically(WakeUpAction*, long int seconds);

  private:

    RealTimeService(const RealTimeService&);
    RealTimeService& operator=(const RealTimeService&);
  };

#endif  // D_RealTimeService_H
