//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_PeopleHomeNotifier_H
#define D_PeopleHomeNotifier_H

///////////////////////////////////////////////////////////////////////////////
//
//  PeopleHomeNotifier is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include <string>
#include "EMail.h"
#include "TimeService.h"
class People;

class PeopleHomeNotifier
  {
  public:
    explicit PeopleHomeNotifier(People* p);
    virtual ~PeopleHomeNotifier();

    virtual void PersonArrived(std::string& rfid);
    virtual void PersonLeft(std::string& rfid);

  private:
    virtual bool AttemptToSend(EMail& mail)
    {
        for (int i = 0; i < 3; i++)
        {
            if (mail.Send())
            {
                return true;
            }
            TimeService::Sleep(10*TimeService::SECONDS);
        }
        return false;
    }


    PeopleHomeNotifier(const PeopleHomeNotifier&);
    PeopleHomeNotifier& operator=(const PeopleHomeNotifier&);

    People* _people;

  };

class PeopleHomeNotifierTest
{
    public:
        explicit PeopleHomeNotifierTest(People* p)
            : _good(false)
        {
        }

        void SetGood(bool val)
        {
            _good = val;
        }

    private:
        bool _good;

        virtual bool AttemptToSend(EMail& mail)
        {
        return _good;
        }
};

#endif  // D_PeopleHomeNotifier_H
