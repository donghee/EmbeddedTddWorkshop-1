//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_BlindsCollection_H
#define D_BlindsCollection_H

///////////////////////////////////////////////////////////////////////////////
//
//  BlindsCollection is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

#include <map>
#include "NullHorizontalBlinds.h"
class HorizontalBlinds;

class BlindsCollection : private std::map<int, HorizontalBlinds*>
{
    public:
        explicit BlindsCollection()
        {
        }

        virtual ~BlindsCollection()
        {
            for(iterator i = begin(); i != end(); i++)
            {
                HorizontalBlinds* b = i->second;
                delete b;
            }
        }

        void add(int id, HorizontalBlinds* b)
        {
            iterator found = find(id);

            if (found != end())
            {
                HorizontalBlinds* f = found->second;
                erase(found);
                delete f;
            }
            insert(std::make_pair(id, b));
        }

        HorizontalBlinds* Find(int id) const
        {
            if (find(id) == end())
            {
                return &nullBlinds;
            }
            return find(id)->second;
        }

        HorizontalBlinds* remove(int id)
        {
            HorizontalBlinds* foundBlinds;

            iterator found = find(id);

            if (found != end())
            {
                foundBlinds = found->second;
                erase(found);
            }
            else
            {
                foundBlinds = new NullHorizontalBlinds();
            }

            return foundBlinds;
        }

    private:
        static NullHorizontalBlinds nullBlinds;
        BlindsCollection(const BlindsCollection&);
        BlindsCollection& operator=(const BlindsCollection&);
};

#endif  // D_BlindsCollection_H
