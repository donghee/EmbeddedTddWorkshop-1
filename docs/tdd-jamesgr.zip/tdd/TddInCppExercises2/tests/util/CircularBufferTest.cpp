//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include <string>
#include "CppUTest/TestHarness.h"
#include "CppUTest/Extensions/SimpleStringExtensions.h"
#include "CircularBuffer.h"

using namespace std;

TEST_GROUP(CircularBuffer)
{
	CircularBuffer* circularBuffer;

	void setup()
	{
		circularBuffer = new CircularBuffer(10);
	}

	void teardown()
	{
		delete circularBuffer;
	}

	void fillTheBuffer(int seed, int count)
	{
		for (int i = 0; i < count; i++)
			circularBuffer->Put(seed++);
	}

	void drainAndCheckBuffer(int seed, int capacity)
	{
		for (int j = 0; j < capacity; j++)
		{
			LONGS_EQUAL(j + seed, circularBuffer->Get());
			CHECK(!circularBuffer->IsFull());
		}
	}

};

TEST(CircularBuffer, CreateDestroy)
{
}

TEST(CircularBuffer, EmptyAfterCreation)
{
	CHECK(circularBuffer->IsEmpty());
}

TEST(CircularBuffer, NotFullAfterCreation)
{
	CHECK(!circularBuffer->IsFull());
}

TEST(CircularBuffer, NotEmpty)
{
	circularBuffer->Put(10046);
	CHECK(!circularBuffer->IsEmpty());
}

TEST(CircularBuffer, NotEmptyThenEmpty)
{
	circularBuffer->Put(4567);
	CHECK(!circularBuffer->IsEmpty());
	circularBuffer->Get();
	CHECK(circularBuffer->IsEmpty());
}

TEST(CircularBuffer, GetPutOneValue)
{
	circularBuffer->Put(4567);
	LONGS_EQUAL(4567, circularBuffer->Get());
}

TEST(CircularBuffer, GetPutAFew)
{
	circularBuffer->Put(1);
	circularBuffer->Put(2);
	circularBuffer->Put(3);
	LONGS_EQUAL(1, circularBuffer->Get());
	LONGS_EQUAL(2, circularBuffer->Get());
	LONGS_EQUAL(3, circularBuffer->Get());
}

TEST(CircularBuffer, Capacity)
{
	CircularBuffer buffer(2);
	LONGS_EQUAL(2, buffer.Capacity());
}

TEST(CircularBuffer, IsFull)
{
	fillTheBuffer(100, circularBuffer->Capacity());

	CHECK(circularBuffer->IsFull());
}

TEST(CircularBuffer, EmptyToFullToEmpty)
{
	fillTheBuffer(100, circularBuffer->Capacity());

	drainAndCheckBuffer(100, circularBuffer->Capacity());
	CHECK(circularBuffer->IsEmpty());
}

TEST(CircularBuffer, WrapAround)
{
	int capacity = circularBuffer->Capacity();
	fillTheBuffer(100, capacity);

	LONGS_EQUAL(100, circularBuffer->Get());
	circularBuffer->Put(1000);
	CHECK(circularBuffer->IsFull());

	drainAndCheckBuffer(101, capacity - 1);

	LONGS_EQUAL(1000, circularBuffer->Get());
	CHECK(circularBuffer->IsEmpty());
}

TEST(CircularBuffer, PutToFullThrows)
{
	fillTheBuffer(900, circularBuffer->Capacity());

	try
	{
		circularBuffer->Put(9999);
		FAIL("Put to full circularBuffer should throw");
	} catch (CircularBufferException& e)
	{
		string expected = "Put to full circular buffer";
		CHECK_EQUAL(expected, e.Message());
	}
}

TEST(CircularBuffer, PutToFullDoesNotDamageContents)
{
	fillTheBuffer(900, circularBuffer->Capacity());

	try
	{
		circularBuffer->Put(9999);
	} catch (CircularBufferException&)
	{
	}

	drainAndCheckBuffer(900, circularBuffer->Capacity());

	CHECK(circularBuffer->IsEmpty());
}

TEST(CircularBuffer, GetFromEmptyThrows)
{
	try
	{
		circularBuffer->Get();
		FAIL("Get from empty should throw");
	} catch (CircularBufferException& e)
	{
		string expected = "Get from empty circular buffer";
		CHECK_EQUAL(expected, e.Message());
		CHECK(circularBuffer->IsEmpty());
	}
}

