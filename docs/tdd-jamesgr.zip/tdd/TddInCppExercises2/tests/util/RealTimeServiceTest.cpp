//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "RealTimeService.h"

TEST_GROUP(RealTimeService)
{
	RealTimeService* timeService;

	void setup()
	{
		timeService = new RealTimeService();
	}

	void teardown()
	{
		delete timeService;
	}
};

TEST(RealTimeService, Create)
{
//	TimeService::Sleep(1);
}

