//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "TimeService.h"
#include "MockTimeService.h"

TEST_GROUP(MockTimeService)
{
	TimeService* timeService;
	MockTimeService* mockTimeService;

	void setup()
	{
		mockTimeService = new MockTimeService();
		timeService = mockTimeService;
	}

	void teardown()
	{
		delete timeService;
	}
};

TEST(MockTimeService, Create)
{
	LONGS_EQUAL(-1, timeService->GetMinute());
	LONGS_EQUAL(TimeService::NONE, timeService->GetDay());
}

TEST(MockTimeService, Set)
{
	mockTimeService->SetMinute(42);
	mockTimeService->SetDay(TimeService::SUNDAY);
	LONGS_EQUAL(42, timeService->GetMinute());
	LONGS_EQUAL(TimeService::SUNDAY, timeService->GetDay());
}

