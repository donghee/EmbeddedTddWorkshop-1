//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "Person.h"
#include "CppUTest/TestHarness.h"

TEST_GROUP(Person)
{
    Person* person1;
    Person* person2;

    void setup()
    {
        person1 = new Person("you", "hey");
        person2 = new Person("", "", person1);
    }

    void teardown()
    {
        delete person2;
        delete person1;
    }
}
;

TEST(Person, Create)
{
}

