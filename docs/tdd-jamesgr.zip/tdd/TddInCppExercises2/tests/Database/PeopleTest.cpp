//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "People.h"
#include "CppUTest/TestHarness.h"

TEST_GROUP(People)
{

    People* people;

    void setup()
    {
        people = new People();
    }

    void teardown()
    {
        delete people;
    }
}
;

TEST(People, Create)
{
}

