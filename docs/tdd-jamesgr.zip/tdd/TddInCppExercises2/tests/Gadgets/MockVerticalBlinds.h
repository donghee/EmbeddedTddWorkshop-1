//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockVerticalBlinds_H
#define D_MockVerticalBlinds_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockVerticalBlinds.h
//
//  MockVerticalBlinds is responsible for providing a test stub for VerticalBlinds
//
///////////////////////////////////////////////////////////////////////////////
#include "VerticalBlinds.h"


class MockVerticalBlinds : public VerticalBlinds
  {
  public:
    explicit MockVerticalBlinds()
    {}
    virtual ~MockVerticalBlinds()
    {}

  private:

    MockVerticalBlinds(const MockVerticalBlinds&);
    MockVerticalBlinds& operator=(const MockVerticalBlinds&);

  };

#endif  // D_MockVerticalBlinds_H
