//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "LightDimmerSwitch.h"
#include "MockLightDimmerSwitch.h"

TEST_GROUP(MockLightDimmerSwitch)
{
    LightDimmerSwitch* lightDimmerSwitch;
    MockLightDimmerSwitch* mockLightDimmerSwitch;

    void setup()
    {
        mockLightDimmerSwitch = new MockLightDimmerSwitch();
        lightDimmerSwitch = mockLightDimmerSwitch;
    }

    void teardown()
    {
        delete lightDimmerSwitch;
    }
}
;

TEST(MockLightDimmerSwitch, Create)
{
    LONGS_EQUAL(0, mockLightDimmerSwitch->GetLevel());
}

TEST(MockLightDimmerSwitch, AdjustLevel)
{
    lightDimmerSwitch->AdjustTo(42);
    LONGS_EQUAL(42, mockLightDimmerSwitch->GetLevel());
}

