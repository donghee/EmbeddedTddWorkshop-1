//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "LightSwitch.h"
#include "MockLightSwitch.h"

TEST_GROUP(MockLightSwitch)
{
	LightSwitch* lightController;
	MockLightSwitch* mockLightController;

	void setup()
	{
		mockLightController = new MockLightSwitch();
		lightController = mockLightController;
	}

	void teardown()
	{
		delete lightController;
	}
};

TEST(MockLightSwitch, Create)
{
	LONGS_EQUAL(UNDEFINED, mockLightController->GetLastId());
	LONGS_EQUAL(UNDEFINED, mockLightController->GetLastState());
}

TEST(MockLightSwitch, RememberTheLastLightIdControlled)
{
	lightController->On(10);
	LONGS_EQUAL(10, mockLightController->GetLastId());
	LONGS_EQUAL(LIGHT_ON, mockLightController->GetLastState());
}
