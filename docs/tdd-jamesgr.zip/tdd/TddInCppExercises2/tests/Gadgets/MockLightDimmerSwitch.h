//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockLightDimmerSwitch_H
#define D_MockLightDimmerSwitch_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockLightDimmerSwitch.h
//
//  MockLightDimmerSwitch is responsible for providing a test stub for LightDimmerSwitch
//
///////////////////////////////////////////////////////////////////////////////
#include "LightDimmerSwitch.h"

class MockLightDimmerSwitch: public LightDimmerSwitch
{
public:
    explicit MockLightDimmerSwitch()
    : level(0)
    {
    }
    virtual ~MockLightDimmerSwitch()
    {
    }

    virtual void AdjustTo(int percentOn)
    {
        level = percentOn;
    }

    int GetLevel() const
    {
        return level;
    }

private:

    int level;

    MockLightDimmerSwitch(const MockLightDimmerSwitch&);
    MockLightDimmerSwitch& operator=(const MockLightDimmerSwitch&);

};

#endif  // D_MockLightDimmerSwitch_H
