//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockMusicPlayer_H
#define D_MockMusicPlayer_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockMusicPlayer.h
//
//  MockMusicPlayer is responsible for providing a test stub for MusicPlayer
//
///////////////////////////////////////////////////////////////////////////////
#include "MusicPlayer.h"


class MockMusicPlayer : public MusicPlayer
  {
  public:
    explicit MockMusicPlayer()
    {}
    virtual ~MockMusicPlayer()
    {}

  private:

    MockMusicPlayer(const MockMusicPlayer&);
    MockMusicPlayer& operator=(const MockMusicPlayer&);

  };

#endif  // D_MockMusicPlayer_H
