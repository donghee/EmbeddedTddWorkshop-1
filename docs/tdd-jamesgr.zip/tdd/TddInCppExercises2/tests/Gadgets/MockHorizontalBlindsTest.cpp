//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "HorizontalBlinds.h"
#include "MockHorizontalBlinds.h"

TEST_GROUP(MockHorizontalBlinds)
{
	HorizontalBlinds* blinds;
	MockHorizontalBlinds* mock;

	int expectedLevel;
	int expectedAngle;

	void setup()
	{
		mock = new MockHorizontalBlinds(42);
		blinds = mock;
		expectedLevel = -1;
		expectedAngle = -1;
	}

	void teardown()
	{
		LONGS_EQUAL(expectedLevel, mock->GetLevel());
		LONGS_EQUAL(expectedAngle, mock->GetAngle());
		delete blinds;
	}
}
;

TEST(MockHorizontalBlinds, Create)
{
}

TEST(MockHorizontalBlinds, FullyRaise)
{
	expectedLevel = HorizontalBlinds::FullyRaised;
	blinds->Raise();
}

TEST(MockHorizontalBlinds, RaiseThenLower)
{
	expectedLevel = HorizontalBlinds::FullyLowered;
	blinds->Raise();
	blinds->Lower();
}

TEST(MockHorizontalBlinds, RaiseThenLowerRelative)
{
	expectedLevel = HorizontalBlinds::FullyRaised - 90;
	blinds->Raise();
	blinds->LowerRelative(90);
}

TEST(MockHorizontalBlinds, MoveToLevelLowerBound)
{
	expectedLevel = HorizontalBlinds::FullyLowered;
	blinds->RaiseAbsolute(expectedLevel);
}

TEST(MockHorizontalBlinds, MoveToLevelUpperBound)
{
	expectedLevel = HorizontalBlinds::FullyRaised;
	blinds->RaiseAbsolute(expectedLevel);
}

TEST(MockHorizontalBlinds, RotateToAngleLowerBound)
{
	expectedAngle = HorizontalBlinds::FullyOpen;
	blinds->LouverOpenAbsolute(expectedAngle);
}

TEST(MockHorizontalBlinds, RotateToAngleUpperBound)
{
	expectedAngle = HorizontalBlinds::FullyClosed;
	blinds->LouverOpenAbsolute(expectedAngle);
}
