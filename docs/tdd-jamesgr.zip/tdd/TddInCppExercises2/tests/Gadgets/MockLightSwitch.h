//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockLightController_H
#define D_MockLightController_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockLightSwitch.h
//
//  MockLightSwitch is responsible for providing a test stub for LightSwitch
//
///////////////////////////////////////////////////////////////////////////////
#include "LightSwitch.h"

#define UNDEFINED -1
#define LIGHT_OFF 0
#define LIGHT_ON 1
#define MAX_LIGHTS 32

class MockLightSwitch : public LightSwitch
  {
  public:

    explicit MockLightSwitch()
    : lastId(UNDEFINED)
    , lastState(UNDEFINED)
    {
        for (int i = 0; i < MAX_LIGHTS; i++)
            lightStates[i] = UNDEFINED;
    }
    virtual ~MockLightSwitch()
    {}

    virtual void On(int id)
    {
        lastId = id;
        lastState = LIGHT_ON;
        lightStates[id] = LIGHT_ON;
    }
    virtual void Off(int id)
    {
        lastId = id;
        lastState = LIGHT_OFF;
        lightStates[id] = LIGHT_OFF;
    }


    int GetLastId() const {return lastId;}
    int GetLastState() const {return lastState;}
    int GetLightState(int id) const {return lightStates[id];}

  private:

      int lastId;
      int lastState;
      int lightStates[MAX_LIGHTS];

    MockLightSwitch(const MockLightSwitch&);
    MockLightSwitch& operator=(const MockLightSwitch&);

  };

#endif  // D_MockLightController_H
