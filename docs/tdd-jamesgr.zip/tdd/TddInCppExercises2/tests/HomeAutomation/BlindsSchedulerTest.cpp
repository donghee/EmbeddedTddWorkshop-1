//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "BlindsScheduler.h"
#include "MockTimeService.h"
#include "MockHorizontalBlinds.h"
#include "NullHorizontalBlinds.h"
#include "CppUTest/TestHarness.h"

TEST_GROUP(BlindsScheduler)
{
	BlindsScheduler* blindsScheduler;
	MockTimeService* mockTime;
	MockHorizontalBlinds* mockBlinds1;
	MockHorizontalBlinds* mockBlinds2;
	NullHorizontalBlinds nullBlinds;
	int id;

	void setup()
	{
		mockTime = new MockTimeService();
		blindsScheduler = new BlindsScheduler(mockTime);
		id = 4;
	}

	void teardown()
	{
		delete blindsScheduler;
		delete mockTime;
	}
}
;

TEST(BlindsScheduler, CreateDestroyDoesNotLeak)
{
}

/*------------------- Add blinds to the system ----------*/
TEST(BlindsScheduler, SchedulerDeletesAddedBlinds)
{
	mockBlinds1 = new MockHorizontalBlinds(1);
	mockBlinds2 = new MockHorizontalBlinds(2);
	blindsScheduler->AddBlinds(1, mockBlinds1);
	blindsScheduler->AddBlinds(2, mockBlinds2);
}

TEST(BlindsScheduler, AddDuplicateIdDoesNoHarm)
{
	mockBlinds1 = new MockHorizontalBlinds(1);
	mockBlinds2 = new MockHorizontalBlinds(1);
	blindsScheduler->AddBlinds(1, mockBlinds1);
	blindsScheduler->AddBlinds(1, mockBlinds2);
}

TEST(BlindsScheduler, FindExistingBlind)
{
	mockBlinds1 = new MockHorizontalBlinds(1);
	blindsScheduler->AddBlinds(1, mockBlinds1);
	HorizontalBlinds* blinds = blindsScheduler->FindBlinds(1);
	LONGS_EQUAL(mockBlinds1->GetId(), blinds->GetId());
}

TEST(BlindsScheduler, FindNonExistantBlindReturnsNullObject)
{
	HorizontalBlinds* blinds = blindsScheduler->FindBlinds(1);
	LONGS_EQUAL(nullBlinds.GetId(), blinds->GetId());
}

TEST(BlindsScheduler, RemoveExistingBlindMustBeDeletedByCaller)
{
	mockBlinds1 = new MockHorizontalBlinds(1);
	blindsScheduler->AddBlinds(1, mockBlinds1);

	HorizontalBlinds* removedBlinds = blindsScheduler->RemoveBlinds(1);

	delete removedBlinds;
}

TEST(BlindsScheduler, RemoveExistingBlind)
{
	mockBlinds1 = new MockHorizontalBlinds(1);
	blindsScheduler->AddBlinds(1, mockBlinds1);

	HorizontalBlinds* removedBlinds = blindsScheduler->RemoveBlinds(1);

	HorizontalBlinds* blinds = blindsScheduler->FindBlinds(1);
	LONGS_EQUAL(mockBlinds1->GetId(), removedBlinds->GetId());
	LONGS_EQUAL(nullBlinds.GetId(), blinds->GetId());
	delete removedBlinds;
}

TEST(BlindsScheduler, RemoveNonExistantBlindReturnAllocatedNullObject)
{
	HorizontalBlinds* removedBlinds = blindsScheduler->RemoveBlinds(2);
	LONGS_EQUAL(nullBlinds.GetId(), removedBlinds->GetId());
	delete removedBlinds;
}

/*---------------------- Raise and Lower the blinds ------------*/
TEST(BlindsScheduler, ScheduleLower)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::MONDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::MONDAY, 1000,
			Horizontal, Lower);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyLowered, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaise)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, Raise);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyRaised, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaiseToLevel)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->Lower();
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, RaiseToLevel, 42);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(42, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaiseToLevelAllUp)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, RaiseToLevel, HorizontalBlinds::FullyRaised);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyRaised, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaiseToLevelTooHigh)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, RaiseToLevel, HorizontalBlinds::FullyRaised + 1);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyRaised, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaiseToLevelAllDown)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, RaiseToLevel, HorizontalBlinds::FullyLowered);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyLowered, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaiseToLevelTooLow)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, RaiseToLevel, HorizontalBlinds::FullyLowered - 1);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyLowered, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaiseRelative)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->Lower();
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, RaiseRelative, 25);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(25, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleRaiseRelativeTooMuchOpensFully)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->Lower();
	mockBlinds1->RaiseRelative(50);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, RaiseRelative, 51);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyRaised, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleLowerRelative)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->Raise();
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, LowerRelative, 25);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(75, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleLowerRelativeTooMuchOpensFully)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->Raise();
	mockBlinds1->LowerRelative(50);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, LowerRelative, 51);

	mockTime->MinuteIsUp();
	LONGS_EQUAL((int) HorizontalBlinds::FullyLowered, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleClose)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::MONDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::MONDAY, 1000,
			Horizontal, Close);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyClosed, mockBlinds1->GetAngle());
}

/*------------------operate the louvers------------------*/
TEST(BlindsScheduler, ScheduleOpen)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleOpenToAngle)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, OpenToAngle, 42);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL(42, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleOpenToMaxAngle)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, OpenToAngle, HorizontalBlinds::FullyOpen);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleOpenBeyondMaxAngle)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, OpenToAngle, HorizontalBlinds::FullyOpen + 1);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleOpenToMinimumAngle)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, OpenToAngle, HorizontalBlinds::FullyClosed);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyClosed, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleOpenBeyondMinimumAngle)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::EVERYDAY, 1000,
			Horizontal, OpenToAngle, HorizontalBlinds::FullyClosed - 1);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyClosed, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleOpenRelative)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, OpenRelative, 30);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL(30, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleOpenRelativeTooMuchOpensFully)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->LouverOpenAbsolute(50);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, OpenRelative, 41);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleCloseRelative)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->LouverOpenAbsolute(45);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, CloseRelative, 45);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyClosed, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleCloseRelativeTooMuchClosesFully)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	mockBlinds1->LouverOpenAbsolute(45);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::TUESDAY, 1000,
			Horizontal, CloseRelative, 46);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL((int) HorizontalBlinds::FullyClosed, mockBlinds1->GetAngle());
}

/*------------------try some other days, etc. --------------------------------*/
TEST(BlindsScheduler, ScheduleNoExactDayMatchBlindsDontReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEDNESDAY, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler,ScheduleNoExactMinuteMatchBlindsDontReact)
{
	mockTime->SetMinute(999);
	mockTime->SetDay(TimeService::TUESDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id,
			TimeService::TUESDAY, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleWeekendAndItsMondayBlindsDontReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::MONDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKEND, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleWeekendAndItsFridayBlindsDontReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::FRIDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKEND, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
	LONGS_EQUAL(-1, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleWeekendAndItsSaturdayBlindsReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::SATURDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKEND, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleWeekendAndItsSundayBlindsReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::SUNDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKEND, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleWeekdayAndItsMondayBlindsReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::MONDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKDAY, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleWeekdayAndItsFridayBlindsReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::FRIDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKDAY, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL((int) HorizontalBlinds::FullyOpen, mockBlinds1->GetAngle());
}

TEST(BlindsScheduler, ScheduleWeekdayAndItsSundayBlindsDontReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::SUNDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKDAY, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
}

TEST(BlindsScheduler, ScheduleWeekdayAndItsSaturdayBlindsDontReact)
{
	mockTime->SetMinute(1000);
	mockTime->SetDay(TimeService::SATURDAY);
	mockBlinds1 = new MockHorizontalBlinds(id);
	blindsScheduler->AddBlinds(id, mockBlinds1);
	blindsScheduler->ScheduleBlindsOperation(id, TimeService::WEEKDAY, 1000,
			Horizontal, Open);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(-1, mockBlinds1->GetLevel());
}

