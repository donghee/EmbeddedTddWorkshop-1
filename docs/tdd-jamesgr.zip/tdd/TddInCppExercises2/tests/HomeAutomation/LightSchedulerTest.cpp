//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "LightScheduler.h"
#include "MockTimeService.h"
#include "MockLightSwitch.h"

TEST_GROUP(LightScheduler)
{
	LightScheduler* lightScheduler;
	MockTimeService* mockTime;
	MockLightSwitch* mockLights;

	void setup()
	{
		mockTime = new MockTimeService();
		mockLights = new MockLightSwitch();
		lightScheduler = new LightScheduler(mockTime, mockLights);
	}

	void teardown()
	{
		delete lightScheduler;
		delete mockTime;
		delete mockLights;
	}
};

TEST(LightScheduler, Create)
{
}

TEST(LightScheduler, CreateDoesNotChangeTheLights)
{
	LONGS_EQUAL(UNDEFINED, mockLights->GetLastId());
	LONGS_EQUAL(UNDEFINED, mockLights->GetLastState());
}

TEST(LightScheduler, CreateStartsOneMinuteAlarm)
{
	CHECK(0 != mockTime->GetCallbackAction());
	LONGS_EQUAL(60000L, mockTime->GetAlarmPeriod());
}

TEST(LightScheduler, ScheduleTwoEventsAtTheSameTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 1200);
	lightScheduler->ScheduleTurnOn(12, TimeService::WEEKDAY, 1200);
	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(1200);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLightState(3));
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLightState(12));
}

TEST(LightScheduler, ScheduleEverydayNotTimeYet)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::EVERYDAY, 500);
	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(499);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(-1, mockLights->GetLastId());
	LONGS_EQUAL(-1, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnTodayItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::EVERYDAY, 500);
	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(3, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnTuesdayAndItsNotTuesdayButItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::TUESDAY, 500);
	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockLights->GetLastId());
	LONGS_EQUAL(-1, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnTuesdayAndItsTuesdayAndItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::TUESDAY, 500);
	mockTime->SetDay(TimeService::TUESDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(3, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOffTuesdayAndItsTuesdayAndItsTime)
{
	lightScheduler->ScheduleTurnOff(3, TimeService::TUESDAY, 500);
	mockTime->SetDay(TimeService::TUESDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(3, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_OFF, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOffWeekendAndItsSaturdayAndItsTime)
{
	lightScheduler->ScheduleTurnOff(4, TimeService::WEEKEND, 500);
	mockTime->SetDay(TimeService::SATURDAY);
	mockTime->SetMinute(500);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(4, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_OFF, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnWeekendAndItsSundayAndItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKEND, 500);
	mockTime->SetDay(TimeService::SUNDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(3, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnWeekendAndItsMondayAndItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKEND, 500);
	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockLights->GetLastId());
	LONGS_EQUAL(-1, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnWeekdayAndItsSundayAndItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 500);
	mockTime->SetDay(TimeService::SUNDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockLights->GetLastId());
	LONGS_EQUAL(-1, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnWeekdayAndItsMondayAndItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 500);
	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(3, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnWeekdayAndItsFridayAndItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 500);
	mockTime->SetDay(TimeService::FRIDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(3, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleOnWeekdayAndItsSaturdayAndItsTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 500);
	mockTime->SetDay(TimeService::SATURDAY);
	mockTime->SetMinute(500);
	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockLights->GetLastId());
	LONGS_EQUAL(-1, mockLights->GetLastState());
}

TEST(LightScheduler, RemoveScheduledEvent)
{
	lightScheduler->ScheduleTurnOn(6, TimeService::MONDAY, 600);
	lightScheduler->ScheduleRemove(6, TimeService::MONDAY, 600);

	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(6000);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(-1, mockLights->GetLastId());
	LONGS_EQUAL(-1, mockLights->GetLastState());
}

TEST(LightScheduler, MultipleScheduledEventsSameTime)
{
	lightScheduler->ScheduleTurnOff(4, TimeService::MONDAY, 500);
	lightScheduler->ScheduleTurnOn(3, TimeService::MONDAY, 500);

	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(500);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLightState(3));
	LONGS_EQUAL(LIGHT_OFF, mockLights->GetLightState(4));
}
TEST(LightScheduler, MultipleScheduledEventsDifferentTimes)
{
	lightScheduler->ScheduleTurnOff(4, TimeService::MONDAY, 600);
	lightScheduler->ScheduleTurnOn(3, TimeService::MONDAY, 500);

	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(500);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(3, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLastState());

	mockTime->SetMinute(600);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(4, mockLights->GetLastId());
	LONGS_EQUAL(LIGHT_OFF, mockLights->GetLastState());
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLightState(3));
	LONGS_EQUAL(LIGHT_OFF, mockLights->GetLightState(4));
}

TEST(LightScheduler, RejectTooManyScheduledItems)
{
	//TODO
}
