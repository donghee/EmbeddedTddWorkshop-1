//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "PeopleHomeNotifier.h"
#include "People.h"
#include "CppUTest/TestHarness.h"

TEST_GROUP(PeopleHomeNotifier)
{
	PeopleHomeNotifierTest* peopleHomeNotifier;
    TestPeople* p;

	void setup()
	{
        p = new TestPeople;
		peopleHomeNotifier = new PeopleHomeNotifierTest(p);
	}

	void teardown()
	{
        delete p;
		delete peopleHomeNotifier;
	}
};

TEST(PeopleHomeNotifier, Create)
{
}

