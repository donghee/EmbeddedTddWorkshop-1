//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "LightScheduler.h"
#include "LightSwitch.h"
#include "TimeService.h"
#include "RandomMinuteGenerator.h"
#include <stdlib.h>
#include <memory.h>


enum {
    TURNON, TURNOFF, RANDOM_ON, RANDOM_OFF
};

enum {
    MAX_EVENTS = 64,
    UNUSED = -1
};

struct ScheduledLightEvent {
    int id;
    TimeService::Day day;
    int minute;
    int event;
    int randomize;
    int randomMinutes;
    int extraREPreventer;
};

static ScheduledLightEvent eventList[MAX_EVENTS];

class LightSchedulerWakeUpAction : public WakeUpAction
{
    LightScheduler* scheduler;

public:
    LightSchedulerWakeUpAction(LightScheduler* scheduler)
    : scheduler(scheduler) {}

    virtual void WakeUp(Time* t) {
        scheduler->WakeUp(t);
    }
};


LightScheduler::LightScheduler(TimeService* timeService, LightSwitch*lightController)
: timeService(timeService)
, lightController(lightController)
, randomMinute(0)
{
    for (int i = 0; i < MAX_EVENTS; i++)
    {
        eventList[i].id = UNUSED;
    }

    randomMinute = new RandomMinuteGenerator(-30, 30);
    timeService->WakePeriodically(new LightSchedulerWakeUpAction(this), 60000);
}

LightScheduler::~LightScheduler()
{
    delete randomMinute;
}

void LightScheduler::WakeUp(Time*)
{
    TimeToCheckTheSchedule();
}


void LightScheduler::ScheduleTurnOn(int id, TimeService::Day day, int minute)
{
    for (int i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id == UNUSED)
        {
            eventList[i].id = id;
            eventList[i].day = day;
            eventList[i].minute = minute;
            eventList[i].event = TURNON;
            eventList[i].randomize = RANDOM_OFF;
            eventList[i].extraREPreventer = 0;
            eventList[i].randomMinutes = 0;
            break;
        }
    }
}

void LightScheduler::ScheduleTurnOnRandomize(int id, TimeService::Day day, int minute)
{
    for (int i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id == UNUSED)
        {
            eventList[i].id = id;
            eventList[i].day = day;
            eventList[i].minute = minute;
            eventList[i].event = TURNON;
            eventList[i].randomize = RANDOM_ON;
            eventList[i].extraREPreventer = 0;
            eventList[i].randomMinutes = 0;
            break;
        }
    }
}

void LightScheduler::ScheduleTurnOff(int id, TimeService::Day day, int minute)
{
    for (int i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id == UNUSED)
        {
            eventList[i].id = id;
            eventList[i].day = day;
            eventList[i].minute = minute;
            eventList[i].event = TURNOFF;
            eventList[i].randomize = RANDOM_OFF;
            eventList[i].extraREPreventer = 0;
            eventList[i].randomMinutes = 0;
            break;
        }
    }
}

void LightScheduler::TimeToCheckTheSchedule()
{
    for (int i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id != UNUSED)
        {
            ScheduledLightEvent* sle = &eventList[i];
            if (sle->extraREPreventer > 0)
            {
                sle->extraREPreventer--;
            }
            else
            {
                int td = timeService->GetDay();

                if ((sle->day == TimeService::EVERYDAY || sle->day == td
                || sle->day == TimeService::WEEKEND
                && (TimeService::SATURDAY == td
                || TimeService::SUNDAY == td)
                || sle->day == TimeService::WEEKDAY
                && td >= TimeService::MONDAY
                && td <= TimeService::FRIDAY))
                {
                    if (timeService->GetMinute() == sle->minute
                            + sle->randomMinutes)
                    {
                        if (TURNON == sle->event)
                            lightController->On(sle->id);
                        else if (TURNOFF == sle->event)
                            lightController->Off(sle->id);

                        if (sle->randomize == RANDOM_ON)
                            sle->randomMinutes = randomMinute->Get();
                        else
                            sle->randomMinutes = 0;

                        sle->extraREPreventer = 61;
                    }
                }
            }
        }
    }
}

void LightScheduler::ScheduleRemove(int id, TimeService::Day day, int minute)
{
    int i;

    for (i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id == id
        && eventList[i].day == day
        && eventList[i].minute == minute)
        {
            eventList[i].id = UNUSED;
        }
    }
}
