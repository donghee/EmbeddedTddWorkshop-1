//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "PeopleHomeNotifier.h"
#include "People.h"
#include "EMail.h"
#include "TimeService.h"

using namespace std;

PeopleHomeNotifier::PeopleHomeNotifier(People* people)
    : _people(people)
{
}

PeopleHomeNotifier::~PeopleHomeNotifier()
{
}

void PeopleHomeNotifier::PersonArrived(string& rfid)
{
     const Person* p = _people->GetByRfid(rfid);

     if (p == 0)
     {
         const Person* admin = _people->GetAdmin();
         EMail mail(admin->GetEMailAddress(), "Unknown person has arrived", "RFID=" + rfid);
         AttemptToSend(mail);
     }
     else
     {
         const Person* p2 = p->GetPersonToNotify();
         if (p2 == 0)
             return;

         EMail mail(p2->GetEMailAddress(), p->GetName() + " is home", "");
         AttemptToSend(mail);
     }
}

void PeopleHomeNotifier::PersonLeft(string& rfid)
{

}
