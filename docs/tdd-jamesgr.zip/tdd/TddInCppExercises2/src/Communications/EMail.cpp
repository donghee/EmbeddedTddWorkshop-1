//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "EMail.h"

using namespace std;

EMail::EMail(string address, string subject, string body)
: address(address)
, subject(subject)
, body(body)
{
}

EMail::~EMail()
{
}

bool EMail::Send()
{
    //send implementation....

    //if cannot connect to server
        return false;

    //more send implementation
}
