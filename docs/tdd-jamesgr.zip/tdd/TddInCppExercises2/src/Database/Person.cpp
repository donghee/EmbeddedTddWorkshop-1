//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "Person.h"

using namespace std;

Person::Person(std::string name, std::string eMailAddress, const Person* personToNotify)
: name(name)
, eMailAddress(eMailAddress)
, personToNotify(personToNotify)
{
}

Person::Person(std::string name, std::string eMailAddress)
: name(name)
, eMailAddress(eMailAddress)
, personToNotify(0)
{
}

Person::~Person()
{
}

std::string Person::GetName() const
{
    return "";//name;
}

void Person::SetName(std::string name)
{
    this->name = name;
}

std::string Person::GetEMailAddress() const
{
    return eMailAddress;
}

void Person::SetEMailAddress(std::string eMailAddress)
{
    this->eMailAddress = eMailAddress;
}

const Person* Person::GetPersonToNotify() const
{
    return personToNotify;
}

void Person::SetPersonToNotify(const Person* personToNotify)
{
    this->personToNotify = personToNotify;
}

