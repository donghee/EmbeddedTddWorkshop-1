//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "People.h"
#include <stdlib.h>

People::People()
{
}

People::~People()
{
}

static Person laura("Laura", "laura@tx.com");
static Person george("George", "george@bb.com", &laura);

const Person* People::SGetAdmin()
{
    //pretend this is from the database
    //and it takes a long time, and it changes
    laura.SetPersonToNotify(&george);
    if (rand() % 2 == 0)
        return &laura;
    else
        return &george;
}


const Person* People::SGetByRfid(std::string rfid)
{
    //pretend this is from the database
    //and it takes a long time, and it changes
    laura.SetPersonToNotify(&george);
    if (rand() % 2 == 0)
        return &laura;
    else
        return &george;
}


