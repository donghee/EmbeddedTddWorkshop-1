//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "RealTimeService.h"

RealTimeService::RealTimeService()
{
}

RealTimeService::~RealTimeService()
{
}

int RealTimeService::GetMinute() const
{
    return 0;//this would have the real OS call
}

RealTimeService::Day RealTimeService::GetDay() const
{
    return SUNDAY;
}

void RealTimeService::WakePeriodically(WakeUpAction*, long int seconds)
{
    /*
     * this would implement a list of wakeup actions, calling
     * them at the right time.
     */
}

