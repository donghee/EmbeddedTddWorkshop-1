//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "Logger.h"
#include <ostream>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

using namespace std;

enum {LOG_MESSAGE_SIZE = 80};

Logger::Logger(string name, int capacity) :
    name(name), capacity(capacity), index(0), logBuffer(0), logCount(0)
{
    clear();
    logBuffer = new vector<char*> (capacity);
    for (int i = 0; i < capacity; i++)
        logBuffer->at(i) = new char[LOG_MESSAGE_SIZE+1];
}

Logger::~Logger()
{
    for (int i = 0; i < capacity; i++)
        delete [] logBuffer->at(i);

    logBuffer->clear();

    delete logBuffer;
}

int Logger::count() const
{
    return logCount;
}

void Logger::log(const char* format, ...)
{
    va_list arguments;
    va_start(arguments, format);
	//-1 is for Microsoft library scompatibility
	if (-1 == vsnprintf(logBuffer->at(index), LOG_MESSAGE_SIZE+1, format, arguments))
		logBuffer->at(index)[LOG_MESSAGE_SIZE] = 0;
    va_end(arguments);

    logCount++;
    index++;
    if (index >= capacity)
        index = 0;
}

void Logger::print(ostream& out) const
{
    int outdex = 0;
    int count = logCount;

    if (count > capacity)
    {
        count = capacity;
        outdex = index;
    }

    out << "MyLogger: " << logCount << " Entries Logged\n";

    for (int i = 0; i < count; i++)
    {
        out << logBuffer->at(outdex) << "\n";
        outdex++;
        if (outdex >= capacity)
            outdex = 0;
    }
    out << "\n";
}

void Logger::clear()
{
    logCount = 0;
    index = 0;
}

