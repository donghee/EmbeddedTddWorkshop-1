//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "LightDimmerSwitch.h"

LightDimmerSwitch::LightDimmerSwitch()
{
}

LightDimmerSwitch::~LightDimmerSwitch()
{
}

