//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "VerticalBlinds.h"

VerticalBlinds::VerticalBlinds()
{
}

VerticalBlinds::~VerticalBlinds()
{
}

