#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Detect feature envy, and fix it using move method.


Instructions
------------
All tests must be passing before beginning.  Create a zip file of the project
with all tests passing, so you can get back to a working state if needed.

Review BlindsScheduler and LightScheduler.
Find the feature envy (one class doing the work of another).



------------ READ ON ONLY AFTER LOOKING LOOKING OVER ----------------------
------------    BlindsScheduler and LightScheduler   ----------------------








You might notice that determining if it is a reaction day is duplicated 
between BlindsScheduler and LightScheduler.  

Where should that code really reside?  Move it there, and write tests for it.

Use the move method refactoring to make the lazy class
do its own work.

Always get the new method on the lazy class compiled before
changing the original code.

Eliminate the busy-body code in both BlindsScheduler and
LightScheduler.

If you get unexpected failures test  use UNDO, don't debug.

Don't forget to add tests for the formerly lazy class.  Considering
the TimeService is all about time, make sure its tests are thorough.

