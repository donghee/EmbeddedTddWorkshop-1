#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Solving a legacy dependency problem using extract method and override.

Instructions
------------
All tests must be passing before beginning.  Check in.


The PeopleHomeNotifier cannot be tested because of:
	- The EMail notifier keeps failing.
	- Once we get the delay wired in is going to slow our tests.  
	We're supposed to wait 10 seconds and retry up to three times.

Use extract and override to break the problem dependency on Mail.Send
and Delay.  Then add the needed tests.  

Don't worry about repeatable data in the database, that is the 
next exercise.
