#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Solving a legacy dependency problem using parameterize constructor.

Instructions
------------
All tests must be passing before beginning.  Check in (zip it).

Random Minute Generator is not tested in the BlindScheduler and 
LightSchduler.  You cannot change the constructor signatures for either
the BlindScheduler or the LightSchduler.  The interface steering committee
is away on an important boondoggle, I mean strategy meeting with GM.
You can create a new constructor for test purposes.

Override the problem dependency by injecting the fake collaborator through 
the overloaded constructor.

Test the randomizing feature of the scheduler.
