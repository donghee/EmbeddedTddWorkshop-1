#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Practice finding long methods and unclear code.
Practice core refactorings.

Instructions
------------
All tests must be passing before beginning.  Create a zip file of the project
with all tests passing, so you can get back to a working state if needed.

Review LightScheduler and its tests.

Find its the long methods, the ones that do not fit in your head quickly, and
refactor them using:
	rename
	extract method
	replace magic number with literal
	restructure to make the code more clear

Smells to look for:
	Long method
	Bad names
	Complex conditionals
	Deep nesting
	Duplication within a class (don't fix duplication between classes, yet)
	
Always know if you expect pass or fail.  If you get unexpected failure, back up
to a safe place then re-think the move.  Don't start debugging, back up
and try again.