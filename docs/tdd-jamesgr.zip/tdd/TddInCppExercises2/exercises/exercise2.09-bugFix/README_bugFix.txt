#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Fixing a bug while being supported by tests.

Instructions
------------
All tests must be passing before beginning.  

Horizontal blinds are getting jammed.  they cannot be moved unless they are 
between 45-90 degrees. Rotate to 45 if needed, move, restore angle.  Start
with the tests.
