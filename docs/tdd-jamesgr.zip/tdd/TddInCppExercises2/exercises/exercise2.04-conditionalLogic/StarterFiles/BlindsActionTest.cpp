#include "CppUTest/TestHarness.h"
#include "BlindsAction.h"

TEST_GROUP(BlindsAction)
{
  BlindsAction* blindsAction;

  void setup()
  {
    blindsAction = new BlindsAction();
  }
  void teardown()
  {
    delete blindsAction;
  }
};

TEST(BlindsAction, Create)
{
  FAIL("Start here");
}

