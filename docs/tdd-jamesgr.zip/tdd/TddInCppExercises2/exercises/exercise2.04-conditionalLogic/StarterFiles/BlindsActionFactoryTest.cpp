#include "CppUTest/TestHarness.h"
#include "BlindsActionFactory.h"

TEST_GROUP(BlindsActionFactory)
{
  BlindsActionFactory* blindsActionFactory;

  void setup()
  {
    blindsActionFactory = new BlindsActionFactory();
  }
  void teardown()
  {
    delete blindsActionFactory;
  }
};

TEST(BlindsActionFactory, Create)
{
  FAIL("Start here");
}

