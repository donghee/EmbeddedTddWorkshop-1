#include "BlindsAction.h"

BlindsAction::BlindsAction()
{
}

BlindsAction::~BlindsAction()
{
}

