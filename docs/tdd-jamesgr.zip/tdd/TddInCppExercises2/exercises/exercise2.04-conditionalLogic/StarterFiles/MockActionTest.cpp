#include "CppUTest/TestHarness.h"
#include "Action.h"
#include "MockAction.h"

TEST_GROUP(Action)
{
  Action* action;
  MockAction* mockAction;

  void setup()
  {
    mockAction = new MockAction();
    action = mockAction;
  }
  void teardown()
  {
    delete action;
  }
};

TEST(Action, Create)
{
  FAIL("Start here");
}
