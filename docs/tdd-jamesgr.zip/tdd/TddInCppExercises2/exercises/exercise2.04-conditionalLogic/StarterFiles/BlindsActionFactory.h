#ifndef D_BlindsActionFactory_H
#define D_BlindsActionFactory_H

///////////////////////////////////////////////////////////////////////////////
//
//  BlindsActionFactory is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class BlindsActionFactory
  {
  public:
    explicit BlindsActionFactory();
    virtual ~BlindsActionFactory();

  private:

    BlindsActionFactory(const BlindsActionFactory&);
    BlindsActionFactory& operator=(const BlindsActionFactory&);

  };

#endif  // D_BlindsActionFactory_H
