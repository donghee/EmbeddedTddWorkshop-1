#ifndef D_Scheduler_H
#define D_Scheduler_H

///////////////////////////////////////////////////////////////////////////////
//
//  Scheduler is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class Scheduler
  {
  public:
    explicit Scheduler();
    virtual ~Scheduler();

  private:

    Scheduler(const Scheduler&);
    Scheduler& operator=(const Scheduler&);

  };

#endif  // D_Scheduler_H
