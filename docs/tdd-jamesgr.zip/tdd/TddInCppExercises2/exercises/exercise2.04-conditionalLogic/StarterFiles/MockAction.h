#ifndef D_MockAction_H
#define D_MockAction_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockAction.h
//
//  MockAction is responsible for providing a test stub for Action
//
///////////////////////////////////////////////////////////////////////////////
#include "Action.h"


class MockAction : public Action
  {
  public:
    explicit MockAction()
    {}
    virtual ~MockAction()
    {}

  private:

    MockAction(const MockAction&);
    MockAction& operator=(const MockAction&);

  };

#endif  // D_MockAction_H
