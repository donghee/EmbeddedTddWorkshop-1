#include "BlindsActionFactory.h"

BlindsActionFactory::BlindsActionFactory()
{
}

BlindsActionFactory::~BlindsActionFactory()
{
}

