#ifndef D_Action_H
#define D_Action_H

///////////////////////////////////////////////////////////////////////////////
//
//  Action is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class Action
  {
  public:
    explicit Action();
    virtual ~Action();

  private:

    Action(const Action&);
    Action& operator=(const Action&);

  };

#endif  // D_Action_H
