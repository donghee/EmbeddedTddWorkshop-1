#ifndef D_BlindsAction_H
#define D_BlindsAction_H

///////////////////////////////////////////////////////////////////////////////
//
//  BlindsAction is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class BlindsAction
  {
  public:
    explicit BlindsAction();
    virtual ~BlindsAction();

  private:

    BlindsAction(const BlindsAction&);
    BlindsAction& operator=(const BlindsAction&);

  };

#endif  // D_BlindsAction_H
