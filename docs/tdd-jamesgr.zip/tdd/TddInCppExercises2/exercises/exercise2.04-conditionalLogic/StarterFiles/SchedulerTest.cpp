#include "CppUTest/TestHarness.h"
#include "Scheduler.h"

TEST_GROUP(Scheduler)
{
  Scheduler* scheduler;

  void setup()
  {
    scheduler = new Scheduler();
  }
  void teardown()
  {
    delete scheduler;
  }
};

TEST(Scheduler, Create)
{
  FAIL("Start here");
}

