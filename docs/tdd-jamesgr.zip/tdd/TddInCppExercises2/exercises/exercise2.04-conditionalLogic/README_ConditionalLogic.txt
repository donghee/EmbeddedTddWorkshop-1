#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Identify the problem conditional logic.
Replace the duplication with polymorphism .
Work in small steps keeping the code running green the whole time.


Instructions
------------
All tests must be passing before beginning.  Create a zip snapshot file 
of the project with all tests passing, so you can get back to a 
working state if needed.

The scheduling function is duplicated between the LightScheduler and
the BlindsScheduler.  As you can see from the giant switch/case
in BlindsScheduler, there are more special cases to come.

Combining the scheduling and the reaction opens all kinds of potential
problems.  Will a blind really open 45 degrees on a Saturday when
scheduled for weekend only operation.  What about all the other
combinations.

If we separate scheduling, from the reaction we can fully test 
all the parts.  We'll have a much more flexible design.

Overall Design:
	Encapsulate each the switch/case clause in its own action class 
	as shown in SchedulerDesign.pdf and feeds them to a generic Scheduler.
	
Overall Incremental Strategy:
	- Encapsulate the whole switch case in one Action.
	- Create and call the Action from the BlindsScheduler.
	- Create a generalized Scheduler class that schedules Actions.  
	
	The BlindsScheduler and LightScheduler will become facades over 
	the Scheduler, delegating to it.
	- Create a BlindsActionFactory that creates an Action for each
	specific blinds Action.

Objective 1: Get the files in place for Action and BlindsAction.

	Create a new interface class called a Action. (Starter files
	provided: Action.*, MockAction.h, MockActionTest.h)
	
	Give Action a single pure virtual function:
	
		virtual void Execute() = 0;
		
	Make your MockAction so that you can check if it has been executed.
	
	Create a BlindsAction based on Action. (Starter files provided)

Objective 2: Extract the switch case into its own free standing
helper function, preparing it to move to the the BlindsAction.Execute();

	The helper function should not dereference any structure or
	access any member data in BlindsScheduler.  Decouple it from 
	BlindsScheduler. The switch should just be about what to 
	do to the blinds. It should not be finding blinds or dereferencing 
	items from the ScheduledBlindsEvent struct.
	
	The signature of the helper function will become the
	signature of the BlindsAction constructor.

Objective 3: 
	BlindsAction's constructor provides the parameters to drive
	the switch/case and its operations.  Only pass these items to the 
	constructor of BlindsAction:
		HorizontalBlinds* 
		type
		operation
		parameter
		
	Note: Eventually each case will be its own action.
	
	Copy the switch/case to the execute method and get it to compile.

	Create a BlindsAction in CheckEvent.
		
	The switch case should be in its original home and also in the 
	BlindsAction at this point. All tests should be passing.
			
	In an easy to undo operation: comment out CheckEvent's call to the
	switch/case helper function and execute the BlindsAction.  All 
	tests should pass.  Fix your leaks.

Take a few deep breaths.  You've made it this far!

Objective 4: Wire the BlindsAction into the blindsEvent.

	- Add an Action pointer to the ScheduledBlindsEvent.  
	- Install the BlindsAction into eventList when adding to the schedule.  
	- Execute blindsEvent->action in CheckEvent rather than creating
	the action and executing it.  
	- Make this work.  Be careful if tests fail.
	- Get rid of the unneeded stuff in ScheduledBlindsEvent once the
	BlindsAction is doing the work.
	
	UNDO and re-think what needs to be fixed. 
	

Objective 5: Get rid of duplication in the ScheduleBlindsOperation.

	You should end up with a helper function that can move to the
	Scheduler when it is time. (I called mine AddToSchedule.)


Objective 6: Create the Scheduler
	
	Create the skeletal new class and test files (provided in StarterFiles).  
	You will be moving your AddToSchedule helper function and ScheduleRemove 
	to Scheduler.  You've done this refactoring before. 

	- WORK INCREMENTALLY!
	- Write a couple tests for Scheduler.  Use your MockAction.
	
Objective 7:  Integrate the Scheduler into BlindsScheduler.  

	Make it so that you can switch between your two 
	implementations with a tiny change, just in case 
	there are problems. Don't burn your bridges. A check-in (i.e. new
	zip snap shot) would be wise.
	
	  Hints:
	     - You can delegate to Scheduler from BlindsScheduler.
	     - Don't start debugging, UNDO and regroup.
	     - When the BlindsSchedule is wakes up, wake up the Scheduler.
	     - Eventually, the BlindsScheduler will just be a domain specific
	       front end on the Scheduler, delegating the real work to it.
	       BlindsScheduler will not need to be awaken at all.  The 
	       Scheduler will do all the waking up.
	       
	- When all tests are passing and the work is being done by the Scheduler,
	  get rid of all the unneeded BlindsSchedule code.
	- Hmmm, it looks like many of those BlindsSchedulerTest should move over
	  to Scheduler.  That's extra credit for later. 
	 
	 Breath a sigh of relief, the hard part is over.
	 
Objective 8: Create a factory to get the Actions.  

	The factory returns an Action*, given a HorizontalBlind, type, 
	operation, and optional parameter.
	
	Test each of the Actions given by the factory to see that it
	behaves correctly.  You should see that the switch/case will 
	eventually end up in its rightful place in the factory and 
	BlindsAction will be obsolete.  BlindsScheduler will use the 
	factory to create the right Action and feed it to the scheduler.
	
	This gets a bit repetitive, after you have a few done, let your
	instructor know.

Extra credit:

	Add these test to the blinds scheduler (and fix them)
		Add the same event twice
		Add an event for a blinds that has not been added to allBlinds.
	     
	Convert the LightScheduler to use the Scheduler 

