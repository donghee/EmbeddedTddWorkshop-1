#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Adding a feature that drops right in as a result of the Open Closed
Principle.


Instructions
------------
All tests must be passing before beginning.  

Add OpenRightVerticalBlinds controller
OpenFull, CloseFull, and associate actions.

Extra credit:
Add support for OpenRelative, CloseRelative, OpenToAbsolute
Rotate(0:180).  These blinds can  only be moved when rotation
is between 45:135.
