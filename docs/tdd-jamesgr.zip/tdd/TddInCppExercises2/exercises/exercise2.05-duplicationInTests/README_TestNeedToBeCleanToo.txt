Objectives
----------
Experience cleaning up your tests.


Instructions
------------
All tests must be passing before beginning.  Check in you code (zip it).

There is too much duplication in the LightScheduler tests.  Clean them up so
that the duplicate code is extracted into helper functions.  Strive to make
the tests easier to understand. 

Extra credit:
	Are there exhaustive tests for TimeService?  No, add them.
	
	Prune back the BlindsScheduler tests that are not needed anymore due to  
	the separate AllBlinds class, TimeService doing its job and
	Scheduler doing its job.