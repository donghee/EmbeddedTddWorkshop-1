#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Solving a legacy dependency problem using Encapsulate static.

Instructions
------------
All tests must be passing before beginning.  Check in.

When there is a class with all static methods, you can't override the
methods for test purposes.  The People class uses statics to get Persons
from the database, but the database keeps changing, so repeatability is 
not possible.

	Add virtual functions to the People class for getting Persons.  The
	virtual functions default behavior is to call the static functions.
	The production code needs to be modified to stop using the statics
	and use the virtual functions instead.  Now you can override them
	for testing.