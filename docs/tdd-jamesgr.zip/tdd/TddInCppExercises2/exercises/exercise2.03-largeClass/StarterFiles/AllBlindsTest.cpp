#include "CppUTest/TestHarness.h"
#include "AllBlinds.h"

TEST_GROUP(AllBlinds)
{
    AllBlinds* allBlinds;

    void setup()
    {
        allBlinds = new AllBlinds();
    }
    void teardown()
    {
        delete allBlinds;
    }
}
;

TEST(AllBlinds, Create)
{
    FAIL("Start here");
}

