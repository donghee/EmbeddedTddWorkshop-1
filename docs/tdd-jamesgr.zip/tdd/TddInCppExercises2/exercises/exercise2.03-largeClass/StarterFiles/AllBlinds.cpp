#include "AllBlinds.h"

AllBlinds::AllBlinds()
{
}

AllBlinds::~AllBlinds()
{
}

