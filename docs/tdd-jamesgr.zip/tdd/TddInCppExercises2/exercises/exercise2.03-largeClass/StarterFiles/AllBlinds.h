#ifndef D_AllBlinds_H
#define D_AllBlinds_H

///////////////////////////////////////////////////////////////////////////////
//
//  AllBlinds is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class AllBlinds
  {
  public:
    explicit AllBlinds();
    virtual ~AllBlinds();

  private:

    AllBlinds(const AllBlinds&);
    AllBlinds& operator=(const AllBlinds&);

  };

#endif  // D_AllBlinds_H
