#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.

Objectives
----------
Sniff out what is making the BlindsScheduler a large class.
Identify something to pull out.  Read the tests.  It
may become obvious that the Single Responsibility Principle
has been violated.  What are the BlindsScheduler's responsibilities?
Make a list, and see what can be pulled out.


------------ Before continuing, answer the above question. ---------------













Instructions
------------
All tests must be passing before beginning.  Create a zip file of the project
with all tests passing, so you can get back to a working state if needed.

BlindsScheduler is growing.  Notice the map that it manages.  Why
should the scheduler manage the collection of all blinds and manage
their scheduled operations.  

Create a skeleton for  new class to be the collection called AllBlinds.
You will find the needed files in StarterFiles.
 
Incrementally encapsulate the map in AllBlinds.
Follow the encapsulate collection refactoring in the notes.

