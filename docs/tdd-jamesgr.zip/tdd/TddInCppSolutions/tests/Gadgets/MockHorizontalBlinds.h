//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockHorizontalBlinds_H
#define D_MockHorizontalBlinds_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockHorizontalBlinds.h
//
//  MockHorizontalBlinds is responsible for providing a test stub
//  for HorizontalBlinds
//
///////////////////////////////////////////////////////////////////////////////
#include "CppUTest/TestHarness.h"
#include "HorizontalBlinds.h"

class MockHorizontalBlinds: public HorizontalBlinds
{
public:
    explicit MockHorizontalBlinds(int id)
    : id(id), level(-1), angle(-1)
    { }

    virtual ~MockHorizontalBlinds() { }

    virtual void Raise() { level = 100; }
    virtual void Lower() { level = 0; }
    virtual void RaiseAbsolute(int percentUp) {
        setAbsoluteWithBounds("Attempt to set blinds level out of bounds",
                level, percentUp, 100); }

    virtual void RaiseRelative(int percentUp) {
        addWithCeiling("Attempt to raise blinds above the top", level, percentUp, 100);
    }

    virtual void LowerRelative(int percentDown) {
        subtractWithFloorAt0("Attempt to lower blinds below the bottom", level, percentDown);
    }

    virtual void LouverOpen() { angle = 90; }
    virtual void LouverClose( ){ angle = 0; }
    virtual void LouverOpenAbsolute(int theta) {
        setAbsoluteWithBounds("Attempt to set louver angle outside bounds", angle, theta, 90); }

    virtual void LouverRelativeOpen(int theta) {
        addWithCeiling("Attempt to rotate louver angle greater than 90", angle, theta, 90);
    }

    virtual void LouverRelativeClose(int theta) {
        subtractWithFloorAt0("Attempt to rotate louver angle to less than 0", angle, theta);
    }

    virtual int GetLevel() const { return level; }
    virtual int GetAngle() const { return angle; }
    virtual int GetId() const { return id; }

private:

    int id;
    int level;
    int angle;

    void addWithCeiling(const char* message, int& value, int delta, int max) {
        if (value == -1) value = 0;
        if ((value + delta) >= max)
        	FAIL(message);
        value += delta;
    }

    void subtractWithFloorAt0(const char* message, int& value, int delta) {
        if (value == -1) value = 0;
        if ((value - delta) < 0)
           	FAIL(message);

        value -= delta;
    }

    void setAbsoluteWithBounds(const char* message, int& value, int theta, int max) {
        if (value == -1) value = 0;
        if (theta < 0 || theta > max)
           	FAIL(message);

        value = theta;
    }

    MockHorizontalBlinds(const MockHorizontalBlinds&);
    MockHorizontalBlinds& operator=(const MockHorizontalBlinds&);
};

#endif  // D_MockHorizontalBlinds_H
