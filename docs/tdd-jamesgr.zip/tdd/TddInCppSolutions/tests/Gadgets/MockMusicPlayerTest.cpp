//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "MusicPlayer.h"
#include "MockMusicPlayer.h"

TEST_GROUP(MockMusicPlayer)
{

    MusicPlayer* musicPlayer;
    MockMusicPlayer* mockMusicPlayer;

    void setup()
    {
        mockMusicPlayer = new MockMusicPlayer();
        musicPlayer = mockMusicPlayer;
    }

    void teardown()
    {
        delete musicPlayer;
    }
};

TEST(MockMusicPlayer,Create)
{
}

