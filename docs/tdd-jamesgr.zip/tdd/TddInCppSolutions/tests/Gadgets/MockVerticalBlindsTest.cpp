//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "VerticalBlinds.h"
#include "MockVerticalBlinds.h"

TEST_GROUP(MockVerticalBlinds)
{

    VerticalBlinds* verticalBlinds;
    MockVerticalBlinds* mockVerticalBlinds;

    void setup()
    {
        mockVerticalBlinds = new MockVerticalBlinds();
        verticalBlinds = mockVerticalBlinds;
    }

    void teardown()
    {
        delete verticalBlinds;
    }
};

TEST(MockVerticalBlinds,Create)
{
}

