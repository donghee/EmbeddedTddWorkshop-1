//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "PeopleHomeNotifier.h"
#include "CppUTest/TestHarness.h"

TEST_GROUP(PeopleHomeNotifier)
{

  PeopleHomeNotifier* peopleHomeNotifier;

public:

  void setup()
  {
    peopleHomeNotifier = new PeopleHomeNotifier();
  }

  void teardown()
  {
    delete peopleHomeNotifier;
  }

};

TEST(PeopleHomeNotifier,Create)
{
}



