//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include <string>
#include "CppUTest/TestHarness.h"
#include "LightScheduler.h"
#include "MockTimeService.h"
#include "MockLightSwitch.h"

TEST_GROUP(LightScheduler)
{
	LightScheduler* lightScheduler;
	MockTimeService* mockTime;
	MockLightController* mockLights;

	void (LightScheduler::*Scheduler)(int id, TimeService::Day day, int minute);
	int id;
	TimeService::Day fakeDay;
	TimeService::Day scheduledDay;
	int fakeMinute;
	int scheduledMinute;
	int expectedId;
	int expectedState;

	void setup()
	{
		mockTime = new MockTimeService();
		mockLights = new MockLightController();
		lightScheduler = new LightScheduler(mockTime, mockLights);

		Scheduler = 0;
		id = 4;
		fakeDay = TimeService::MONDAY;
		scheduledDay = TimeService::NONE;
		fakeMinute = 1234;
		scheduledMinute = 1234;
		expect(TimeService::NONE, TimeService::NONE);
	}

	void teardown()
	{
		delete lightScheduler;
		delete mockTime;
		delete mockLights;
	}

	void doTest() {
		CHECK(0 != Scheduler);

		(lightScheduler->*Scheduler)(id, scheduledDay, scheduledMinute);

		mockTime->SetMinute(fakeMinute);
		mockTime->SetDay(fakeDay);
		mockTime->MinuteIsUp();
		LONGS_EQUAL(expectedId, mockLights->GetLastId());
		LONGS_EQUAL(expectedState, mockLights->GetLastState());
	}

	void expect(int id, int level) {
		expectedId = id;
		expectedState = level;
	}

};

TEST(LightScheduler,Create)
{
}

TEST(LightScheduler,CreateDoesNotChangeTheLights)
{
	LONGS_EQUAL(UNDEFINED, mockLights->GetLastId());
	LONGS_EQUAL(UNDEFINED, mockLights->GetLastState());
}

TEST(LightScheduler,CreateStartsOneMinuteAlarm)
{
	CHECK(0 != mockTime->GetCallbackAction());
	CHECK(3600 == mockTime->GetAlarmPeriod());
}

TEST(LightScheduler,ScheduleTwoEventsAtTheSameTime)
{
	lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 1200);
	lightScheduler->ScheduleTurnOn(12, TimeService::WEEKDAY, 1200);
	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(1200);

	mockTime->MinuteIsUp();

	LONGS_EQUAL(LIGHT_ON, mockLights->GetLightState(3));
	LONGS_EQUAL(LIGHT_ON, mockLights->GetLightState(12));
}

TEST(LightScheduler,ScheduleEverydayNotTimeYet)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::EVERYDAY;
	scheduledMinute = fakeMinute + 1;
	expect(UNDEFINED, UNDEFINED);
	doTest();
}

TEST(LightScheduler,ScheduleOnTodayItsTime)
{

	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::EVERYDAY;
	scheduledMinute = fakeMinute;
	expectedId = id;
	expect(id, LIGHT_ON);
	doTest();
}

TEST(LightScheduler,ScheduleOnTuesdayAndItsNotTuesdayButItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::TUESDAY;
	scheduledMinute = fakeMinute;
	doTest();
}

TEST(LightScheduler,ScheduleOnTuesdayAndItsTuesdayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = fakeDay = TimeService::TUESDAY;
	scheduledMinute = fakeMinute;
	expect(id, LIGHT_ON);
	doTest();
}

TEST(LightScheduler,ScheduleOffTuesdayAndItsTuesdayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOff;
	scheduledDay = fakeDay = TimeService::TUESDAY;
	scheduledMinute = fakeMinute;
	expect(id, LIGHT_OFF);
	doTest();
}

TEST(LightScheduler,ScheduleOffWeekendAndItsSaturdayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOff;
	scheduledDay = TimeService::WEEKEND;
	fakeDay = TimeService::SATURDAY;
	scheduledMinute = fakeMinute;
	expect(id, LIGHT_OFF);
	doTest();
}

TEST(LightScheduler,ScheduleOnWeekendAndItsSundayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::WEEKEND;
	fakeDay = TimeService::SUNDAY;
	scheduledMinute = fakeMinute;
	expect(id, LIGHT_ON);
	doTest();
}

TEST(LightScheduler,ScheduleOnWeekendAndItsMondayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::WEEKEND;
	fakeDay = TimeService::MONDAY;
	scheduledMinute = fakeMinute;
	doTest();
}

TEST(LightScheduler,ScheduleOnWeekdayAndItsSundayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::WEEKDAY;
	fakeDay = TimeService::SUNDAY;
	scheduledMinute = fakeMinute;
	doTest();
}

TEST(LightScheduler,ScheduleOnWeekdayAndItsMondayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::WEEKDAY;
	fakeDay = TimeService::MONDAY;
	scheduledMinute = fakeMinute;
	expect(id, LIGHT_ON);
	doTest();
}

TEST(LightScheduler,ScheduleOnWeekdayAndItsFridayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::WEEKDAY;
	fakeDay = TimeService::FRIDAY;
	scheduledMinute = fakeMinute;
	expect(id, LIGHT_ON);
	doTest();
}

TEST(LightScheduler,ScheduleOnWeekdayAndItsSaturdayAndItsTime)
{
	Scheduler = &LightScheduler::ScheduleTurnOn;
	scheduledDay = TimeService::WEEKDAY;
	fakeDay = TimeService::SATURDAY;
	scheduledMinute = fakeMinute;
	doTest();
}

TEST(LightScheduler,RemoveScheduledEvent)
{
	lightScheduler->ScheduleTurnOn(6, TimeService::MONDAY, 600);
	lightScheduler->ScheduleRemove(6, TimeService::MONDAY, 600);

	mockTime->SetDay(TimeService::MONDAY);
	mockTime->SetMinute(6000);

	mockTime->MinuteIsUp();
	LONGS_EQUAL(UNDEFINED, mockLights->GetLastId());
	LONGS_EQUAL(UNDEFINED, mockLights->GetLastState());
}

#if 0
TEST(LightScheduler,MultipleScheduledEventsSameTime)
{
	lightScheduler->ScheduleTurnOff(4, MONDAY, 500);
	lightScheduler->ScheduleTurnOn(3, MONDAY, 500);

	mockTime->SetDay(MONDAY);
	mockTime->SetMinute(500);

	lightScheduler->Wakeup();
	LONGS_EQUAL(2, FakeLightController_getEventCounts());
}
TEST(LightScheduler,MultipleScheduledEventsDifferentTimes)
{
	lightScheduler->ScheduleTurnOff(4, MONDAY, 600);
	lightScheduler->ScheduleTurnOn(3, MONDAY, 500);

	mockTime->SetDay(MONDAY);
	mockTime->SetMinute(500);

	lightScheduler->Wakeup();
	LONGS_EQUAL(3, FakeLightController_getLastId());
	LONGS_EQUAL(LIGHT_ON, FakeLightController_getLastState());

	mockTime->SetMinute(600);

	lightScheduler->Wakeup();
	LONGS_EQUAL(4, FakeLightController_getLastId());
	LONGS_EQUAL(LIGHT_OFF, FakeLightController_getLastState());
}

#endif

