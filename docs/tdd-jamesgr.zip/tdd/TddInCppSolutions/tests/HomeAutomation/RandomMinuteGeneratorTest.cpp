//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "RandomMinuteGenerator.h"
#include <stdio.h>
#include <string.h>

TEST_GROUP(RandomMinuteGenerator)
{

  RandomMinuteGenerator* randomMinuteGenerator;

  enum {LowerBound = -30, UpperBound = 30, PossibleValues = 61};

  void setup()
  {
    randomMinuteGenerator = new RandomMinuteGenerator(LowerBound, UpperBound);
  }

  void teardown()
  {
    delete randomMinuteGenerator;
  }
};

TEST(RandomMinuteGenerator,Create)
{
}

TEST(RandomMinuteGenerator,GetIsInRange)
{
  int minute;

  for (int i = 0; i < 100; i++)
  {
	  minute = randomMinuteGenerator->Get();
	  if (minute < LowerBound || minute > UpperBound)
	  {
		  printf("bad minute value: %d\n", minute);
		  FAIL("Minute out of range");
	  }
  }
}

TEST(RandomMinuteGenerator,AllValuesPossible)
{
  int minute;
  int hit[PossibleValues];
  memset(hit, 0, sizeof(hit));

  for (int i = 0; i < 1000; i++)
  {
	  minute = randomMinuteGenerator->Get();
	  if (minute < LowerBound || minute > UpperBound)
	  {
		  printf("bad minute value: %d\n", minute);
		  FAIL("Minute out of range");
	  }
	  hit[minute + UpperBound]++;
  }

  for (int i = 0; i < PossibleValues; i++) {
	  CHECK(hit[i] > 0);
  }
}



