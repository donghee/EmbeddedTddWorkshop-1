//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "EMail.h"
#include "CppUTest/TestHarness.h"

TEST_GROUP(EMail)
{

  EMail* eMail;

  void setup()
  {
    eMail = new EMail("", "", "");
  }

  void teardown()
  {
    delete eMail;
  }
};

TEST(EMail,Create)
{
}



