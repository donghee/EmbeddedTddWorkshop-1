//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_People_H
#define D_People_H

///////////////////////////////////////////////////////////////////////////////
//
//  People is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include "Person.h"
#include <string>

class People
  {
  public:
    explicit People();
    virtual ~People();

    static const Person* GetAdmin() ;
    static const Person* GetByRfid(std::string rfid) ;

  private:

    People(const People&);
    People& operator=(const People&);

  };

#endif  // D_People_H
