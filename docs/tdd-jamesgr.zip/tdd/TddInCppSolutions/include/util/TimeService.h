//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_TimeService_H
#define D_TimeService_H

///////////////////////////////////////////////////////////////////////////////
//
//  TimeService is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class WakeUpAction;
struct Time;

class TimeService
  {

  public:

      enum Day {
        NONE=-1, EVERYDAY=10, WEEKDAY, WEEKEND,
        SUNDAY=1, MONDAY, TUESDAY, WEDNESDAY,
        THURSDAY, FRIDAY, SATURDAY
    };

    explicit TimeService();
    virtual ~TimeService();

    virtual int GetMinute() const = 0;
    virtual Day GetDay() const = 0;
    virtual void WakePeriodically(WakeUpAction*, long int seconds) = 0;

  private:

    TimeService(const TimeService&);
    TimeService& operator=(const TimeService&);

  };

class WakeUpAction
{
public:
    WakeUpAction();
    virtual ~WakeUpAction();
    virtual void WakeUp(Time*) = 0;
private:
    WakeUpAction(const WakeUpAction&);
    WakeUpAction& operator=(const WakeUpAction&);
};

#endif  // D_TimeService_H
