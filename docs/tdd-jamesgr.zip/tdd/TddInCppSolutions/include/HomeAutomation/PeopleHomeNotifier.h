//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_PeopleHomeNotifier_H
#define D_PeopleHomeNotifier_H

///////////////////////////////////////////////////////////////////////////////
//
//  PeopleHomeNotifier is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include <string>


class PeopleHomeNotifier
  {
  public:
    explicit PeopleHomeNotifier();
    virtual ~PeopleHomeNotifier();

    virtual void PersonArrived(std::string& rfid);
    virtual void PersonLeft(std::string& rfid);

  private:


    PeopleHomeNotifier(const PeopleHomeNotifier&);
    PeopleHomeNotifier& operator=(const PeopleHomeNotifier&);

  };

#endif  // D_PeopleHomeNotifier_H
