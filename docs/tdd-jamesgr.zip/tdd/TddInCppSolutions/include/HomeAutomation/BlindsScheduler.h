//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_BlindsScheduler_H
#define D_BlindsScheduler_H

///////////////////////////////////////////////////////////////////////////////
//
//  BlindsScheduler is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

#include <map>
#include "TimeService.h"

class Time;
class HorizontalBlinds;
class RandomMinuteGenerator;
struct ScheduledBlindsEvent;

enum BlindsType { Horizontal, LeftOpeningVertical, RightOpeningVertical };
enum BlindsOperation { Raise, Lower, RaiseToLevel, RaiseRelative, LowerRelative,
    Open, Close, OpenToAngle, OpenRelative, CloseRelative,
    };

class BlindsScheduler
  {
  public:
    explicit BlindsScheduler(TimeService*);
    virtual ~BlindsScheduler();

    virtual void AddBlinds(int id, HorizontalBlinds*);
    virtual HorizontalBlinds* FindBlinds(int id);
    virtual HorizontalBlinds* RemoveBlinds(int id);

    void ScheduleBlindsOperation(int id, TimeService::Day day, int minute,
            BlindsType, BlindsOperation);

    void ScheduleBlindsOperation(int id, TimeService::Day day, int minute,
            BlindsType, BlindsOperation, int blindsParameter);

    void ScheduleRemove(int id, TimeService::Day day, int minute);
    void ScheduleTurnOnRandomize(int id, TimeService::Day day, int minute);
    void WakeUp(Time*);


  private:

    TimeService* timeService;
    std::map<int, HorizontalBlinds*>* blinds;
    RandomMinuteGenerator* randomMinute;

    void CheckEvent(ScheduledBlindsEvent*);
    bool DoesLightRespondToday(TimeService::Day);
    void TimeToCheckTheSchedule();
    void ScheduleEvent(int id, TimeService::Day day, int minute, int event, int randomize);
    void Randomize(ScheduledBlindsEvent* e);

    BlindsScheduler(const BlindsScheduler&);
    BlindsScheduler& operator=(const BlindsScheduler&);

  };




#endif  // D_BlindsScheduler_H
