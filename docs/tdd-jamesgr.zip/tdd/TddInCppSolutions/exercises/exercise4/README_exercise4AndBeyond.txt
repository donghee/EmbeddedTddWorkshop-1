Objectives
----------



Refactoring exercises
1) Long method -> Extract method
2) Feature envy -> Move mehtod
3) Large class, colleciton -> Encasulate collection
4) Conditional logic -> replace type code with polymorphism
5) Refactor the test files

Design
SPR
DRY
Substitutability
MYOB
SoC

Legacy
1) Problem dependency, inject collaborator through overloaded constructors
   Random Minute Generator is not tested in the BlindScheduler and 
   LightSchduler.  You cannot change the constructor for either the 
   BlindScheduler and LightSchduler.  The interface steeering committe
   is away on an important boondoggle, I mean strategy meeting.
   Use blah...
2) Problem dependency, extract into method and override
   Eamil notification
   SQL database access
3) Encapsualte static

Add more features
1) Horizontal blinds are gettgin jammed.  they cannot be moved unless they are 
   between 45-90 degrees. Rotate to 45 if needed, move, restore angle

2) Add OpenRightVerticalBlinds blinds controller
   OpenFull, CloseFull, OpenRelative, CloseRelative, OpenToAbsolute
   Rotate(0:180).  can only be moved when rotate is 45:135
   
Threading exercise