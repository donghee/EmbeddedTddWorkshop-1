//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "TimeService.h"

TimeService::TimeService()
{
}

TimeService::~TimeService()
{
}

WakeUpAction::WakeUpAction()
{

}

WakeUpAction::~WakeUpAction()
{

}
