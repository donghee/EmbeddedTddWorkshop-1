//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "LightScheduler.h"
#include "LightSwitch.h"
#include "TimeService.h"
#include "RandomMinuteGenerator.h"
#include <stdlib.h>
#include <memory.h>


enum {
    TURNON, TURNOFF, RANDOM_ON, RANDOM_OFF
};

enum {
    MAX_EVENTS = 64,
    UNUSED = -1
};

struct ScheduledLightEvent {
    int id;
    TimeService::Day day;
    int minute;
    int event;
    int randomize;
    int randomMinutes;
    int extraRandomEventPreventer;
};

static ScheduledLightEvent eventList[MAX_EVENTS];

class LightSchedulerWakeUpAction : public WakeUpAction
{
    LightScheduler* scheduler;

public:
    LightSchedulerWakeUpAction(LightScheduler* scheduler)
    : scheduler(scheduler) {}

    virtual void WakeUp(Time* t) {
        scheduler->WakeUp(t);
    }
};


LightScheduler::LightScheduler(TimeService* timeService, LightSwitch*lightController)
: timeService(timeService)
, lightController(lightController)
, randomMinute(0)
{
    int i;
    for (i = 0; i < MAX_EVENTS; i++)
    {
        eventList[i].id = UNUSED;
    }

    randomMinute = new RandomMinuteGenerator(-30, 30);
    timeService->WakePeriodically(new LightSchedulerWakeUpAction(this), 3600);
}

LightScheduler::~LightScheduler()
{
    delete randomMinute;
}

void LightScheduler::WakeUp(Time*)
{
    TimeToCheckTheSchedule();
}


void LightScheduler::Randomize(ScheduledLightEvent* e)
{
    if (e->randomize == RANDOM_ON)
        e->randomMinutes = randomMinute->Get();
    else
        e->randomMinutes = 0;
}

void LightScheduler::ScheduleEvent(int id, TimeService::Day day, int minute, int event, int randomize)
{
    for (int i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id == UNUSED)
        {
            eventList[i].id = id;
            eventList[i].day = day;
            eventList[i].minute = minute;
            eventList[i].event = event;
            eventList[i].randomize = randomize;
            eventList[i].extraRandomEventPreventer = 0;
            Randomize(&eventList[i]);
            break;
        }
    }
}

void LightScheduler::ScheduleTurnOn(int id, TimeService::Day day, int minute)
{
    ScheduleEvent(id, day, minute, TURNON, RANDOM_OFF);
}

void LightScheduler::ScheduleTurnOnRandomize(int id, TimeService::Day day, int minute)
{
    ScheduleEvent(id, day, minute, TURNON, RANDOM_ON);
}

void LightScheduler::ScheduleTurnOff(int id, TimeService::Day day, int minute)
{
    ScheduleEvent(id, day, minute, TURNOFF, RANDOM_OFF);
}

bool LightScheduler::DoesLightRespondToday(TimeService::Day reactionDay)
{
    int today = timeService->GetDay();

    if (reactionDay == TimeService::EVERYDAY)
        return true;
    if (reactionDay == today)
        return true;
    if (reactionDay == TimeService::WEEKEND
            && (TimeService::SATURDAY == today || TimeService::SUNDAY == today))
        return true;
    if (reactionDay == TimeService::WEEKDAY
            && today >= TimeService::MONDAY && today <= TimeService::FRIDAY)
        return true;
    return false;
}


void LightScheduler::CheckEvent(ScheduledLightEvent* lightEvent)
{
    if (lightEvent->extraRandomEventPreventer > 0) {
        lightEvent->extraRandomEventPreventer--;
        return;
    }

    if (!DoesLightRespondToday(lightEvent->day))
        return;
    if (timeService->GetMinute() != lightEvent->minute + lightEvent->randomMinutes)
        return;

    if (TURNON == lightEvent->event)
         lightController->On(lightEvent->id);
    else if (TURNOFF == lightEvent->event)
         lightController->Off(lightEvent->id);

    Randomize(lightEvent);
    lightEvent->extraRandomEventPreventer = 61;
    //how should we get rid of this magic number?
}

void LightScheduler::TimeToCheckTheSchedule()
{
    for (int i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id != UNUSED)
            CheckEvent(&eventList[i]);
    }
}

void LightScheduler::ScheduleRemove(int id, TimeService::Day day, int minute)
{
    int i;

    for (i = 0; i < MAX_EVENTS; i++)
    {
        if (eventList[i].id == id
        && eventList[i].day == day
        && eventList[i].minute == minute)
        {
            eventList[i].id = UNUSED;
        }
    }
}
