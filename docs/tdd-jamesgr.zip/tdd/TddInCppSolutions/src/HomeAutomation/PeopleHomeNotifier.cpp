//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "PeopleHomeNotifier.h"
#include "People.h"
#include "EMail.h"

using namespace std;

PeopleHomeNotifier::PeopleHomeNotifier()
{
}

PeopleHomeNotifier::~PeopleHomeNotifier()
{
}

void PeopleHomeNotifier::PersonArrived(string& rfid)
{
     const Person* p = People::GetByRfid(rfid);

     if (p == 0)
     {
         const Person* admin = People::GetAdmin();
         EMail mail(admin->GetEMailAddress(), "Unknown person has arrived", "RFID=" + rfid);
         for (int i = 0; i < 3; i++)
         {
             if (mail.Send())
                 return;
             //delay
         }
     }
     else
     {
         const Person* p2 = p->GetPersonToNotify();
         if (p2 == 0)
             return;

         EMail mail(p2->GetEMailAddress(), p->GetName() + " is home", "");
         for (int i = 0; i < 3; i++)
         {
             if (mail.Send())
                 return;
             //delay
         }
     }
}

void PeopleHomeNotifier::PersonLeft(string& rfid)
{

}
