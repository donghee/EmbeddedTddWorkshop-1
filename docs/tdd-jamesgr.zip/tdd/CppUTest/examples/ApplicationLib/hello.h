
#ifndef HELLO_H_
#define HELLO_H_

extern void printHelloWorld();

extern int (*PrintFormated) (const char*, ...);

#endif /*HELLO_H_*/
