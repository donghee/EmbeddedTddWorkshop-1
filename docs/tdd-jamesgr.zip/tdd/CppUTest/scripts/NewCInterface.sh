#!/bin/bash
TEMPLATE_DIR=${CPP_U_TEST}/scripts/templates
source ${CPP_U_TEST}/scripts/GenerateSrcFiles.sh ClassNameC c Fake $1 $2

