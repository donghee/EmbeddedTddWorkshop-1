//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_Logger_H
#define D_Logger_H

///////////////////////////////////////////////////////////////////////////////
//
//  Logger is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////
#include <string>
#include <iosfwd>


class Logger
  {
  public:
    explicit Logger(std::string name);
    virtual ~Logger();

    int count() const;
    void print(std::ostream&);

  private:

     std::string name;

    Logger(const Logger&);
    Logger& operator=(const Logger&);

  };

#endif  // D_Logger_H
