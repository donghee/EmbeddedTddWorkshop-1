//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_CircularBuffer_H
#define D_CircularBuffer_H

#include <list>
#include <string>

class CircularBuffer
{
public:
    explicit CircularBuffer(unsigned int = 5);
    virtual ~CircularBuffer();

    bool IsEmpty() const;
    bool IsFull() const;
    unsigned int Capacity() const;
    void Put(int);
    int Get();

private:

    CircularBuffer(const CircularBuffer&);
    CircularBuffer& operator=(const CircularBuffer&);

    unsigned int _capacity;
    typedef std::list<int> Buffer;
    Buffer _buffer;
    Buffer::iterator _current;

    int* _ptr;
};

class CircularBufferException
{
    public:
        CircularBufferException(const std::string& s)
            : _message(s)
        {
        }

        inline std::string Message() const
        {
            return _message;
        }
    private:
        const std::string _message;

};

#endif  // D_CircularBuffer_H
