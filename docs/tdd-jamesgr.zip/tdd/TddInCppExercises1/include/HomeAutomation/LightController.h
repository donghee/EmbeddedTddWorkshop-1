//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_LightController_H
#define D_LightController_H

///////////////////////////////////////////////////////////////////////////////
//
//  LightController is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class LightController
{
    public:
        explicit LightController();
        virtual ~LightController();

        virtual void On(int id) = 0;
        virtual void Off(int id) = 0;

    private:

        LightController(const LightController&);
        LightController& operator=(const LightController&);

};

typedef int LightControllerException;

#endif  // D_LightController_H
