//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_LightScheduler_H
#define D_LightScheduler_H

///////////////////////////////////////////////////////////////////////////////
//
//  LightScheduler is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

#include <string>
#include <list>
#include "TimeService.h"

class LightController;

struct Event
{
    Event(int i, TimeService::Day d, int m, bool o)
        : index(i)
        , day(d)
        , minute(m)
        , turnOn(o)
    {
    }

    int index;
    TimeService::Day day;
    int minute;
    bool turnOn;
};

class ScheduleException : public std::string
{
    public:
        ScheduleException(const std::string& str)
            : std::string(str)
        {
        }
};

class LightScheduler
{
    public:
        explicit LightScheduler(TimeService* service, LightController* controller);
        virtual ~LightScheduler();

        void ScheduleTurnOn(int index, TimeService::Day, int minute);
        void ScheduleTurnOff(int index, TimeService::Day, int minute);
        void RemoveSchedule();
        void WakeUp();

        static bool isSpecificDay(TimeService::Day day);
        static bool isWeekend(TimeService::Day day);
        static bool isWeekday(TimeService::Day day);

    private:
        void checkMinuteAndAct(const Event& event);
        void checkEventAndAct(const Event& event);

    private:

        LightScheduler(const LightScheduler&);
        LightScheduler& operator=(const LightScheduler&);

        typedef std::list<Event> Events;
        Events _events;

        TimeService* _timeService;
        LightController* _lightController;

};

#endif  // D_LightScheduler_H
