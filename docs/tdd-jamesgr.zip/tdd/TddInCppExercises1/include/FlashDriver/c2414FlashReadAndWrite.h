#ifndef D_c2414FlashReadAndWrite_H
#define D_c2414FlashReadAndWrite_H

#include "c2414.h"

uCPUBusType  FlashRead( udword udAddrOff );
void  FlashWrite( udword udAddrOff, uCPUBusType ucVal );

#endif

//Original code thanks to STMicroelectronics.

