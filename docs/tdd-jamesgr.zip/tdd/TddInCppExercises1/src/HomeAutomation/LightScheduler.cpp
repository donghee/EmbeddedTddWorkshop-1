//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "LightScheduler.h"
#include "LightController.h"
#include <assert.h>

LightScheduler::LightScheduler(TimeService* service, LightController* controller)
    : _timeService(service)
    , _lightController(controller)
{
}

LightScheduler::~LightScheduler()
{
}

void LightScheduler::ScheduleTurnOn(int index, TimeService::Day day, int minute)
{
    if(_events.size() >= 128)
    {
        throw ScheduleException("Yo");
    }
    Event event(index, day, minute, true);
    _events.push_back(event);
}

void LightScheduler::ScheduleTurnOff(int index, TimeService::Day day, int minute)
{
    if(_events.size() >= 128)
    {
        throw ScheduleException("Yo");
    }
    Event event(index, day, minute, false);
    _events.push_back(event);
}

void LightScheduler::RemoveSchedule()
{
    _events.clear();
}

void LightScheduler::WakeUp()
{
    for(Events::const_iterator iEvent = _events.begin(); iEvent != _events.end(); ++iEvent)
    {
        checkEventAndAct(*iEvent);
    }
}

void LightScheduler::checkEventAndAct(const Event& event)
{
    if(isSpecificDay(event.day))
    {
        if(event.day == _timeService->GetDay())
        {
            checkMinuteAndAct(event);
        }
    }
    else if(event.day == TimeService::WEEKEND)
    {
        if(isWeekend(_timeService->GetDay()))
        {
            checkMinuteAndAct(event);
        }
    }
    else if(event.day == TimeService::WEEKDAY)
    {
        if(isWeekday(_timeService->GetDay()))
        {
            checkMinuteAndAct(event);
        }
    }
    else
    {
        checkMinuteAndAct(event);
    }
}

void LightScheduler::checkMinuteAndAct(const Event& event)
{
    if(_timeService->GetMinute() == event.minute)
    {
        if(event.turnOn)
        {
            _lightController->On(event.index);
        }
        else
        {
            _lightController->Off(event.index);
        }
    }

}
bool LightScheduler::isSpecificDay(TimeService::Day day)
{
    return day > TimeService::BEFORE_FIRST_DAY && day < TimeService::PAST_LAST_DAY;
}

bool LightScheduler::isWeekend(TimeService::Day day)
{
    return day == TimeService::SUNDAY || day == TimeService::SATURDAY;
}

bool LightScheduler::isWeekday(TimeService::Day day)
{
    return ! isWeekend(day);
}
