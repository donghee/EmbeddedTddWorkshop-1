//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "LightController.h"

LightController::LightController()
{
	//Hardware dependent initialization code
}

LightController::~LightController()
{
	//Hardware dependent cleanup code
}

//the rest of the implementation
