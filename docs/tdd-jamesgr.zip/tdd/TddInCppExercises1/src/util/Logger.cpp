//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "Logger.h"
#include "CppUTest/TestHarness.h"
#include <ostream>


using namespace std;
Logger::Logger(string name)
: name(name)
{
}

Logger::~Logger()
{
}

int Logger::count() const
{
    return 0;
}

void Logger::print(ostream& o)
{
    o <<  "MyLogger: 0 Entries\n"
    "\n";
}
