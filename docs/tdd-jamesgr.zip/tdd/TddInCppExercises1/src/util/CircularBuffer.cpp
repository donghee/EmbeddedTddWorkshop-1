//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CircularBuffer.h"

CircularBuffer::CircularBuffer(unsigned int capacity)
    : _capacity(capacity)
    , _current(_buffer.begin())
{
}

CircularBuffer::~CircularBuffer()
{
}

unsigned int CircularBuffer::Capacity() const
{
    return _capacity;
}

bool CircularBuffer::IsEmpty() const
{
    return _buffer.empty();
}

bool CircularBuffer::IsFull() const
{
    return _buffer.size() >= _capacity;
}

void CircularBuffer::Put(int i)
{
    if(_buffer.size() >= _capacity)
    {
        throw CircularBufferException("Put to full circular buffer");
    }

    _buffer.push_back(i);
    if(_buffer.size() == 1)
    {
        _current = _buffer.begin();
    }
}

int CircularBuffer::Get()
{
    if(_current == _buffer.end())
    {
        throw CircularBufferException("Get from empty circular buffer");
    }

    int val = *_current;
    _current = _buffer.erase(_current);

    return val;
}
