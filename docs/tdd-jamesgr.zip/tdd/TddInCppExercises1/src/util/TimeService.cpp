//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "TimeService.h"

TimeService::TimeService()
{
	//OS dependent initialization
}

TimeService::~TimeService()
{
	//OS dependent cleanup
}

WakeUpAction::WakeUpAction()
{
}

WakeUpAction::~WakeUpAction()
{
}
