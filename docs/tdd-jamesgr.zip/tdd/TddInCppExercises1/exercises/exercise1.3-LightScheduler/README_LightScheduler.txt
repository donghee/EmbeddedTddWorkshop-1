#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.


Objectives
----------
Use an interface class to decouple code under tests with its
collaborating objects.

Use TDD to create the light scheduler shown in the slides.


Light scheduler requirements.
-----------------------------
The light scheduler maintains a schedule of up to 32 lights that can
be turned on, or off.  Multiple schedules per light are supported.  
Schedules can be established by day of the week (M Tu W Th F Sa Su), 
weekdays, weekends, or everyday.

The light scheduler is woke up once a minute to see if any lights 
need controlling.  A total of 128 individual schedules are supported.

Exercise Instructions
---------------------
Review the generated production code starter files:
        include/HomeAutomation/LightScheduler.h
        src/HomeAutomation/LightScheduler.cpp
        tests/HomeAutomation/LightSchedulerTest.cpp
        
Review the time service files and its fake implementation:  
       include/util/TimeService.h
       src/util/TimeService.cpp
       tests/MockTimeService.h
       tests/MockTimeServiceTest.cpp

Define the LightController interface and fake implementation 
as shown in the course materials using these provided files.
        include/HomeAutomation/LightController.h
        src/HomeAutomation/LightController.cpp
        tests/HomeAutomation/LightControllerTest.cpp
        tests/HomeAutomation/MockLightController.h
        tests/HomeAutomation/MockLightControllerTest.cpp

Here is a starter test list for the LightScheduler.  Brainstorm a 
few more test cases with your partner.
   1) A light scheduled to turn on, does not turn on at the wrong time.
   2) A light scheduled to turn on, does turn on at the right time.
   3) A light scheduled to turn off, does turn off at the right time.
   4) A light scheduled for a specific day of the week works.
   5) Schedule for weekends.
   6) Schedule for weekdays.
   7) Remove a scheduled light, the removed light's on-time happens, 
        and the light is not turned on.
   8) Schedule two lights, turn them on/off at different times.
   9) Schedule two lights, turn them on/off at the same time.
   10) Boundary and error cases

Start implementing tests from the test list.  Before tests #8
and #9 and you only need a single event.  No array of light events 
is needed before #8.  Do not add any scheduled light events collection
behavior until the tests call for it.

DO NOT WRITE PRODUCTION CODE UNLESS THERE IS A FAILING TEST CASE 
REQUIRING THAT CODE.

MAKE SURE YOU LET YOUR TESTS FAIL FIRST.

Take turns with the keyboard.



