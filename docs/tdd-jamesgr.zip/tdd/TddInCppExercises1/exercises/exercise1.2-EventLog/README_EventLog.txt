#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.


Exercise Objective
------------------
From a requirements statement, design a event logging class using TDD.

Part One
--------
Create a test list from the requirements below.  Write the tests on
a note card or piece of paper.  Order the tests to help you work 
incrementally and have a thoroughly tested event log class when 
completed.

In a few minutes we will review the test list as a group.

Event Log Requirements
----------------------
The event log keeps the last N logged items for retrieval on demand. 
N is set by the application. Each logger has a name which is printed
when the log is printed. The logger has an array of print lines of 
up to 80 characters. The logger should have minimal performance impact, and
can run when the heap is exhausted. Therefore there is no
dynamic memory allocation done except at logger startup. The
call to log something supports multiple arguments, exactly the
same as printf does.

Exercise Instructions
---------------------
Starting from the skeleton of the Logger files provided, incrementally 
test and build the Logger class.  Get most of the logger implemented
by only logging strings.  Don't deal with the circular nature of the log
until the basics are working.  Add the integration of printf style
formatted output after all else is working.

Follow the TDD Microcycle!


DO NOT WRITE PRODUCTION CODE UNLESS THERE IS A FAILING TEST CASE 
REQUIRING THAT CODE.

MAKE SURE YOU LET YOUR TESTS FAIL FIRST.

Take turns with the keyboard.



