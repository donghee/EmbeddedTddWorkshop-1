#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.


Exercise Objective
------------------
Experience the rhythm
Build useful, fully tested code.
Get the feel for working in small steps.
Experience pair programming.

Before you start
----------------
Review the project directory structure. For this exercise you are
interested in the "util" package.  It is structured like this:

include/util
srs/util
tests/util

The include and src directories contain production code, the tests
directory contains the test code.

Requirements
------------
Create a CircularBuffer class.  If has first-in first-out (FIFO) 
semantics.  It has a construction time defined capacity.  See 
CircularBuffer.pdf for a diagram of a circular buffer.

Test List
- - - - -
Empty after creation
Not empty after full
Full indication
Transition to Empty
Transition from full to not full
Put/Get support FIFO behavior
Get from empty
Put to full
Wrap around

Exercise Instructions
---------------------
This is a simulation of you and your partner pair programming 
with me, an experienced TDD programmer.

DO NOT WRITE PRODUCTION CODE UNLESS THERE IS A FAILING TEST CASE 
REQUIRING THAT CODE.

If you see your partner letting the code get ahead of the tests, your
job is to ask, "Do you have a test for that?"  Please take turns at 
the keyboard.

WARNING: As your instructor, I reserve the right to delete any
code not required by your current test cases. You might consider
it my duty!

Open CircularBuffer.h, CircularBuffer.c, and CircularBufferTest.cpp.
Make the failing tests pass by deleting the line causing the failure.

Enable one test at a time by moving the #if 0 down the file.  Compile, 
run, write code to make it pass. For hints and instructions, read the 
comments as you go.

If there are lines of code commented out, enable one line of code at
a time. Compile and run the tests. 

Eliminate compiler problems first, by modifying the header file.  
You should see a link error.  Then write the implementation in 
the cpp file to make the link error go away. Watch the test run, 
but fail.  

Finally make the test pass. Experienced TDD programmers work in 
small steps with regular feedback.

Keep your code warning free.

OK, get started..
---------------------
We're playing TDD ping pong. I write a test, you make it pass.  
Take turns driving the keyboard.  Talk to your partner. Get help
if you get stuck.

DO NOT WRITE PRODUCTION CODE UNLESS THERE IS A FAILING TEST CASE 
REQUIRING THAT CODE.

MAKE SURE YOU LET YOUR TESTS FAIL FIRST.

Take turns with the keyboard.

