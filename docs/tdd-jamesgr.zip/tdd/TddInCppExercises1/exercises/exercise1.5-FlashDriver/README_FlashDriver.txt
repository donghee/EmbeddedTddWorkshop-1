#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.


Copyright (c) Renaissance Software Consulting
---------------------------------------------

Objectives
----------
Use a self verifying mock object to assure the right IO operations 
are made by the FlashDriver.  Write code using TDD from a device 
specification.

Instructions
------------
DO NOT WRITE PRODUCTION CODE UNLESS THERE IS A FAILING TEST CASE 
REQUIRING THAT CODE.

You know the drill.

Requirements
------------
The Flash Specification exercises/m28w160ect.pdf, for your reference, is 
found in the exercises folder.

Implement MyFlashBlockErase driver.  
See flowchart in Figure 20. "Erase Flowchart and Pseudo Code"  


Test strategy
-----------------
Get the requirements from the spec (m28w160ect.pdf).  Use the provided
mock object to intercept and control interactions with the hardware.


Exercise Instructions
---------------------
Review the existing tests in FlashTest.cpp and the mock object code to 
understand how the MockC2414ReadAndWrite works.

Don't look at the reference design BlockErase in c2414.c.  Add your own
version of the BlockErase function to the end of that file.  Call your
version MyFlashBlockErase.

Based on reviewing the spec, how many test cases do you need for 
MyFlashBlockErase?  Make a test list.

Implement the function incrementally using TDD.  

When you are finished, compare your implementation to the  
reference  provided by the vendor.  See if the vendor's implementation 
passes your tests.  Then write the test that exercises for the vendor's 
BlockErase implementation.

Extra Credit
------------
Implement MyFlashProtectionRegister driver.  
See flowchart in Figure 23. "Protection Register Program Flowchart 
and Pseudo Code"  
