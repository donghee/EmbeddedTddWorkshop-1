#- Copyright (c) 2008-2009 James Grenning
#- All rights reserved
#- For use by participants in James' training courses.


Objectives
----------
Tests must be kept clean.  Too much copy and paste makes for
fragile tests, and tests that do not tell their story to the reader.
In this exercise you will practice cleaning up some of the mess
you made of the tests.

Exercise Instructions
---------------------
Find duplication between tests and extract it into TEST_GROUP
helper functions.  Make the purpose of the tests obvious.  Change
test names to describe the tests intent.

Work incrementally.  Don't cut and paste to make your helper.
Copy, paste, edit, compile, cut-over to helper.  Keep your tests 
running.  Undo if you have an unexpected failure.
