//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include <string>
#include "CppUTest/TestHarness.h"
#include "CppUTest/Extensions/SimpleStringExtensions.h"
#include "CircularBuffer.h"

using namespace std;

TEST_GROUP(CircularBuffer)
{
	CircularBuffer* circularBuffer;

	void setup()
	{
		circularBuffer = new CircularBuffer();
	}

	void teardown()
	{
		delete circularBuffer;
	}

    void fillTheBuffer(int seed, unsigned int capacity)
    {
        for (unsigned int i = 0; i < capacity; i++)
        {
            circularBuffer->Put(i + seed);
        }
    }

    void drainAndCheckBuffer(int seed, unsigned int capacity)
    {
        for (unsigned int i = 0; i < capacity; i++)
        {
            LONGS_EQUAL(i + seed, circularBuffer->Get());
        }
    }
}
;

IGNORE_TEST(CircularBuffer, Create)
{
	FAIL("Start here");
}

/*
 * TDD Exercise
 *
 * The purpose of this exercise is to give you a feel for
 * pair programming with an experienced TDD developer
 *
 * When starting, brain storm a list of needed tests.
 * Here is the initial list we came up with:
 * Empty
 * Not empty
 * Simple put and get
 * setable capactiy
 * totally full, but no more
 * over filled with wrap around
 * underflow, taking items out of an empty buffer
 *
 * The process is
 * write a failing unit test
 * make it compile
 * make it link
 * run the test and see it fail
 * add simplest code to make the test pass
 *
 * The initial state of this code is failing
 * Delete the FAIL macro call, compile and see that all tests pass
 *
 * To get the feel of TDD enable only one test at a time
 * Like this:
 *
 *   Move the #if down the page.  Study the test, make
 *   sure you understand what the test is trying to
 *   accomplish.  Read the test name.  You are
 *   pretending to pair program with me.  I just wrote
 *   the first test, you need to make it pass.
 *
 *   Don't forget to add the CPPUNIT_TEST(testName)
 *   invocation before CPPUNIT_TEST_SUITE_END() as you
 *   enable the new test.  Your test will not run unless
 *   you do.  That macro wires the test case into the test
 *   harness.  If you make sure you watch each new test
 *   fail before adding the passing implementation, you will
 *   catch when you forget to add the CPPUNIT_TEST(testName).
 *
 *   Each time you enable new code, follow this careful process:
 *   1) Get the test to compile.  This usually means just
 *   getting the header file right.  Once the header file is
 *   right you will have a linker error.
 *   2) Get rid of the link error by adding a trivial, but
 *   failing, implementation to the cpp file.
 *   3) Finally, add the simplest implementation that will
 *   allow the test to pass.  Sometimes this means hard
 *   coding a return value. Don't let the code get ahead of
 *   the tests.
 *
 *   Now go to the next test.
 *
 * You will find some more instruction down the page
 */

TEST(CircularBuffer, EmptyAfterCreation)
{
	CHECK(circularBuffer->IsEmpty());
}

TEST(CircularBuffer, NotFullAfterCreation)
{
	CHECK(!circularBuffer->IsFull());
}


TEST(CircularBuffer, NotEmptyAfterPut)
{
	circularBuffer->Put(10046);
	CHECK(!circularBuffer->IsEmpty());
}


TEST(CircularBuffer, NotEmptyThenEmpty)
{
	circularBuffer->Put(4567);
	CHECK(!circularBuffer->IsEmpty());
	circularBuffer->Get();
	CHECK(circularBuffer->IsEmpty());
}

TEST(CircularBuffer, GetPutOneValue)
{
	circularBuffer->Put(4567);
	LONGS_EQUAL(4567, circularBuffer->Get());
}



/*
 * With the previous tests passing you should have at most a counter
 * that knows how many ints have been added to the buffer, with
 * hard coded return value for Get()
 *
 * If you have more, delete it now!  it is not tested code, you
 * are supposed to be doing TDD!
 */

TEST(CircularBuffer, GetPutAFew)
{
	circularBuffer->Put(1);
	circularBuffer->Put(2);
	circularBuffer->Put(3);
	LONGS_EQUAL(1, circularBuffer->Get());
	LONGS_EQUAL(2, circularBuffer->Get());
	LONGS_EQUAL(3, circularBuffer->Get());
}

    /*
     * The previous test has driven you to have a simple internal array
     * of fixed size, an index and an outdex.  There should
     * be no circular buffer logic yet.
     * Why?  your tests do not require it yet.
     */

TEST(CircularBuffer, Capacity)
    {
        CircularBuffer buffer(2);
        LONGS_EQUAL(2, buffer.Capacity());
    }

    /*
     * Did you create the internal buffer with new?  Take it out.
     * All you need is to have parameterized the constructor and
     * added a capacity getter.
     *
     * Did you add a second constructor? or Did you change the default
     * to parameterized?  I recommend the later.  I also suggest that
     * you create the buffer in setup with 5 or more elements.
     */

TEST(CircularBuffer, IsFull)
    {
        fillTheBuffer(100, circularBuffer->Capacity());

        CHECK(circularBuffer->IsFull());
    }


    /*
     * With the is full test, the simple array should be replaced with an
     * array created using new.  Did you get a memory leak?  If you did not
     * remove the delete from your destructor to see what happens.  Try
     * delete with and without square brackets [ ].
     */

    /*
     * With the EmptyToFullToEmpty test there is still no need for
     * the wrap around logic. If you have wrap around logic already,
     * raise your hand and show me your untested code so I can delete it.
     */

TEST(CircularBuffer, EmptyToFullToEmpty)
    {
        fillTheBuffer(100, circularBuffer->Capacity());
        drainAndCheckBuffer(100, circularBuffer->Capacity());

        CHECK(circularBuffer->IsEmpty());
    }


    /*
     * Did that test pass without changes to the production code?
     *
     * Finally, the wrap around test. Sometimes this test will crash the
     * tests when your buffer boundary is violated.
     */

TEST(CircularBuffer, WrapAround)
    {
        int capacity = circularBuffer->Capacity();
        fillTheBuffer(100, circularBuffer->Capacity());

        LONGS_EQUAL(100, circularBuffer->Get());
        circularBuffer->Put(1000);
        CHECK(circularBuffer->IsFull());

        for (int i = 1; i < capacity; i++)
            LONGS_EQUAL(i + 100, circularBuffer->Get());

        LONGS_EQUAL(1000, circularBuffer->Get());
        CHECK(circularBuffer->IsEmpty());
    }


    /*
     *  Did wrap around test pass without change? Beware, you are
     *  trashing something.
     *
     *  By now you should be sick of writing the fill loop over
     *  and over again.  Refactor the loop into the fillTheBuffer
     *  function, add it as a private function.  Get rid of all
     *  the duplication.
     *
     *  You get rid of the duplication around draining and
     *  checking of the buffer too.
     *
     *  You should not have any production code that is worried
     *  about doing a Get from an empty buffer, or putting to
     *  a full buffer.  You will worry about that in the next
     *  test.  TDD, remember?
     *
     */

TEST(CircularBuffer, PutToFullThrows)
    {
        fillTheBuffer(900, circularBuffer->Capacity());

        try
        {
            circularBuffer->Put(9999);
            FAIL("Put to full circularBuffer should throw");
        }
        catch (CircularBufferException& e)
        {
            string expected = "Put to full circular buffer";
            CHECK_EQUAL(expected, e.Message());
        }
    }

TEST(CircularBuffer, PutToFullDoesNotDamageContents)
    {
        fillTheBuffer(900, circularBuffer->Capacity());

        try
        {
            circularBuffer->Put(9999);
        }
        catch (CircularBufferException& e)
        {
        }

        drainAndCheckBuffer(900, circularBuffer->Capacity());

        CHECK(circularBuffer->IsEmpty());
    }

    /*
     * Don't you think you should refactor that duplicate index
     * wrapping code into a helper function in your production code?
     *
     * You should also refactor the tests so that the get/check loop
     * is not duplicated.
     */

TEST(CircularBuffer, GetFromEmptyThrows)
    {
        try
        {
            circularBuffer->Get();
            FAIL("Get from empty should throw");
        }
        catch (CircularBufferException& e)
        {
            string expected = "Get from empty circular buffer";
            CHECK_EQUAL(expected, e.Message());
            CHECK(circularBuffer->IsEmpty());
        }
    }

TEST(CircularBuffer, JumpAround)
    {
        circularBuffer->Put(1);
        circularBuffer->Put(2);
        circularBuffer->Put(3);
        LONGS_EQUAL(1, circularBuffer->Get());
        LONGS_EQUAL(2, circularBuffer->Get());
        circularBuffer->Put(4);
        circularBuffer->Put(5);
        circularBuffer->Put(6);
        LONGS_EQUAL(3, circularBuffer->Get());
        LONGS_EQUAL(4, circularBuffer->Get());
        LONGS_EQUAL(5, circularBuffer->Get());
        circularBuffer->Put(7);
        LONGS_EQUAL(6, circularBuffer->Get());
        LONGS_EQUAL(7, circularBuffer->Get());

        CHECK(circularBuffer->IsEmpty());
    }
#if 0   //Move this line down one test at a time

    /*
     * Did you delete all the unneeded comments?
     */

#endif

