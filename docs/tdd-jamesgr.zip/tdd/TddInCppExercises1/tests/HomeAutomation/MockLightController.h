//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockLightController_H
#define D_MockLightController_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockLightController.h
//
//  MockLightController is responsible for providing a test stub for LightController
//
///////////////////////////////////////////////////////////////////////////////
#include "LightController.h"

class MockLightController : public LightController
{
    public:
        enum State
        {
            UNDEFINED, LIGHT_ON, LIGHT_OFF
        };

        explicit MockLightController()
            : lastId(UNDEFINED)
            , lastState(UNDEFINED)
        {
        }

        virtual ~MockLightController()
        {
        }

        virtual void On(int id)
        {
            lastId = id;
            lastState = LIGHT_ON;
        }

        virtual void Off(int id)
        {
            lastId = id;
            lastState = LIGHT_OFF;
        }

        int GetLastId() const
        {
            return lastId;
        }

        int GetLastState() const
        {
            return lastState;
        }

    private:

        int lastId;
        int lastState;


        MockLightController& operator=(const MockLightController&);

};

#endif  // D_MockLightController_H
