//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockTimeService_H
#define D_MockTimeService_H

///////////////////////////////////////////////////////////////////////////////
//
//  MockTimeService.h
//
//  MockTimeService is responsible for providing a test stub for TimeService
//
///////////////////////////////////////////////////////////////////////////////
#include "TimeService.h"

class MockTimeService: public TimeService
{
public:
    explicit MockTimeService() :
        minute(-1), day(NONE), wakeUpAction(0), seconds(-1)
    {
    }
    virtual ~MockTimeService()
    {
        delete wakeUpAction;
    }

    virtual int GetMinute() const
    {
        return minute;
    }
    virtual Day GetDay() const
    {
        return day;
    }

    void SetMinute(int minute)
    {
        this->minute = minute;
    }

    void SetDay(TimeService::Day day)
    {
        this->day = day;
    }

    void MinuteIsUp()
    {
        if (0 != wakeUpAction)
            wakeUpAction->WakeUp(0);
    }

    WakeUpAction* GetCallbackAction()
    {
        return wakeUpAction;
    }

    long int GetAlarmPeriod()
    {
        return seconds;
    }

    void WakePeriodically(WakeUpAction* wakeUpAction, long int seconds)
    {
        this->wakeUpAction = wakeUpAction;
        this->seconds = seconds;
    }

private:

    int minute;
    TimeService::Day day;
    WakeUpAction* wakeUpAction;
    long int seconds;

    MockTimeService(const MockTimeService&);
    MockTimeService& operator=(const MockTimeService&);
};

#endif  // D_MockTimeService_H
