//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "LightScheduler.h"
#include "MockLightController.h"
#include "MockTimeService.h"
#include "CppUTest/TestHarness.h"

TEST_GROUP(LightScheduler)
{
    LightScheduler* lightScheduler;

    MockLightController* mockLights;

    MockTimeService* mockTime;

    void setup()
    {
        mockLights = new MockLightController();

        mockTime = new MockTimeService();

        lightScheduler = new LightScheduler(mockTime, mockLights);
    }

    void teardown()
    {
        delete lightScheduler;
        delete mockLights;
        delete mockTime;
    }

    void setTimeAndWake(TimeService::Day day, int minute)
    {
        mockTime->SetDay(day);
        mockTime->SetMinute(minute);
        lightScheduler->WakeUp();
    }

    void TestTwoLights( TimeService::Day dayOn1
                      , int minuteOn1
                      , TimeService::Day dayOn2
                      , int minuteOn2
                      , TimeService::Day dayOff2
                      , int minuteOff2
                      )
    {
        lightScheduler->ScheduleTurnOn(3, dayOn1, minuteOn1);
        lightScheduler->ScheduleTurnOn(6, dayOn2, minuteOn2);
        lightScheduler->ScheduleTurnOff(6, dayOff2, minuteOff2);

        // time stamp - nothing yet
        setTimeAndWake(dayOn1, minuteOn1 - 1);

        LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastId());
        LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastState());

        // time stamp - first light
        setTimeAndWake(dayOn1, minuteOn1);

        LONGS_EQUAL(3, mockLights->GetLastId());
        LONGS_EQUAL(MockLightController::LIGHT_ON, mockLights->GetLastState());

        // time stamp - not at second light yet
        setTimeAndWake(dayOn1, minuteOn1 + 1);

        LONGS_EQUAL(3, mockLights->GetLastId());
        LONGS_EQUAL(MockLightController::LIGHT_ON, mockLights->GetLastState());

        // time stamp - second light
        setTimeAndWake(dayOn2, minuteOn2);

        LONGS_EQUAL(6, mockLights->GetLastId());
        LONGS_EQUAL(MockLightController::LIGHT_ON, mockLights->GetLastState());

        // time stamp - no change
        setTimeAndWake(dayOn2, minuteOn2 + 1);

        LONGS_EQUAL(6, mockLights->GetLastId());
        LONGS_EQUAL(MockLightController::LIGHT_ON, mockLights->GetLastState());

        // time stamp - second light goes off
        setTimeAndWake(dayOff2, minuteOff2);

        LONGS_EQUAL(6, mockLights->GetLastId());
        LONGS_EQUAL(MockLightController::LIGHT_OFF, mockLights->GetLastState());
    }
};

TEST(LightScheduler, Create)
{
}

TEST(LightScheduler, TurnOnEverydayNotTimeYest)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::EVERYDAY, 500);

    setTimeAndWake(TimeService::MONDAY, 499);

    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastState());
}

TEST(LightScheduler, TurnOnTodayItsTime)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::EVERYDAY, 500);

    setTimeAndWake(TimeService::MONDAY, 500);

    LONGS_EQUAL(3, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, TurnOffTodayItsTime)
{
    lightScheduler->ScheduleTurnOff(3, TimeService::EVERYDAY, 500);

    setTimeAndWake(TimeService::MONDAY, 500);

    LONGS_EQUAL(3, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::LIGHT_OFF, mockLights->GetLastState());
}

TEST(LightScheduler, TurnOnTuesday)
{
    lightScheduler->ScheduleTurnOff(3, TimeService::TUESDAY, 500);

    setTimeAndWake(TimeService::TUESDAY, 500);

    LONGS_EQUAL(3, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::LIGHT_OFF, mockLights->GetLastState());
}

TEST(LightScheduler, IsSpecificDay)
{
    CHECK(LightScheduler::isSpecificDay(TimeService::MONDAY));
    CHECK(LightScheduler::isSpecificDay(TimeService::TUESDAY));
    CHECK(LightScheduler::isSpecificDay(TimeService::WEDNESDAY));
    CHECK(LightScheduler::isSpecificDay(TimeService::THURSDAY));
    CHECK(LightScheduler::isSpecificDay(TimeService::FRIDAY));
    CHECK(LightScheduler::isSpecificDay(TimeService::SATURDAY));
    CHECK(LightScheduler::isSpecificDay(TimeService::SUNDAY));

    CHECK(! LightScheduler::isSpecificDay(TimeService::NONE));
    CHECK(! LightScheduler::isSpecificDay(TimeService::EVERYDAY));
    CHECK(! LightScheduler::isSpecificDay(TimeService::WEEKDAY));
    CHECK(! LightScheduler::isSpecificDay(TimeService::WEEKEND));
}

TEST(LightScheduler, TurnOnTuesdayNotMonday)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::TUESDAY, 500);

    setTimeAndWake(TimeService::MONDAY, 500);

    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastState());
}

TEST(LightScheduler, DoesntTurnOnWhenScheduledForWeekend)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::WEEKEND, 500);

    setTimeAndWake(TimeService::MONDAY, 500);

    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastState());
}

TEST(LightScheduler, TurnOnWhenScheduledForWeekend)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::WEEKEND, 500);

    setTimeAndWake(TimeService::SATURDAY, 500);

    LONGS_EQUAL(3, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, DoesntTurnOnWhenScheduledForWeekday)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 500);

    setTimeAndWake(TimeService::SATURDAY, 500);

    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastState());
}

TEST(LightScheduler, TurnOnWhenScheduledForWeekday)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::WEEKDAY, 500);

    setTimeAndWake(TimeService::WEDNESDAY, 500);

    LONGS_EQUAL(3, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::LIGHT_ON, mockLights->GetLastState());
}

TEST(LightScheduler, AddSchedulerRemoveScheduleDoesntTurnOn)
{
    lightScheduler->ScheduleTurnOn(3, TimeService::EVERYDAY, 500);
    lightScheduler->RemoveSchedule();

    setTimeAndWake(TimeService::MONDAY, 499);

    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastId());
    LONGS_EQUAL(MockLightController::UNDEFINED, mockLights->GetLastState());
}

TEST(LightScheduler, ScheduleTwoLightsDifferentTimes)
{
    TestTwoLights(TimeService::SATURDAY, 500, TimeService::TUESDAY, 500, TimeService::TUESDAY, 600);
}

TEST(LightScheduler, ScheduleTwoLightsSimilarTime)
{
    TestTwoLights(TimeService::SATURDAY, 500, TimeService::TUESDAY, 500, TimeService::TUESDAY, 600);
}

TEST(LightScheduler, MaxScedule)
{
    try
    {
        for(int i = 0; i < 200; ++i)
        {
            lightScheduler->ScheduleTurnOn(3, TimeService::EVERYDAY, i);
        }
        FAIL("SHOULD GET EXCEPTION");
    }
    catch(ScheduleException& e)
    {
    }

    try
    {
        lightScheduler->ScheduleTurnOff(3, TimeService::EVERYDAY, 201);
        FAIL("SHOULD GET EXCEPTION");
    }
    catch(ScheduleException& e)
    {
    }
}
