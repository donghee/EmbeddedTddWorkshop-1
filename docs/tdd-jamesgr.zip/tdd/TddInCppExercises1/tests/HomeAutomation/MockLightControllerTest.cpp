//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"
#include "LightController.h"
#include "MockLightController.h"

TEST_GROUP(LightController)
{
  LightController* lightController;
  MockLightController* mockLightController;

  void setup()
  {
    mockLightController = new MockLightController();
    lightController = mockLightController;
  }
  void teardown()
  {
    delete lightController;
  }
};

//TEST(LightController, Create)
//{
//    CHECK(! lightController->isOn(0));
//}
//
//TEST(LightController, TurnOn)
//{
//    lightController->turnOn(0);
//    CHECK(lightController->isOn(0));
//}
//
//TEST(LightController, TurnOnThenOff)
//{
//    lightController->turnOn(0);
//    CHECK(lightController->isOn(0));
//    lightController->turnOff(0);
//    CHECK(! lightController->isOn(0));
//}
//
//TEST(LightController, TurnOffAlreadyOff)
//{
//    CHECK(! lightController->isOn(0));
//    lightController->turnOff(0);
//    CHECK(! lightController->isOn(0));
//}
//
//TEST(LightController, TurnOnAlreadyOn)
//{
//    lightController->turnOn(0);
//    CHECK(lightController->isOn(0));
//    lightController->turnOn(0);
//    CHECK(lightController->isOn(0));
//}
//
//TEST(LightController, TurnOn1OnlyOneOn)
//{
//    lightController->turnOn(0);
//    CHECK(lightController->isOn(0));
//    CHECK(! lightController->isOn(1));
//}
//
//TEST(LightController, OutOfRange)
//{
//    try
//    {
//        lightController->turnOn(32);
//        FAIL("Should have thrown");
//    }
//    catch(LightControllerException& e)
//    {
//    }
//}
