//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include <string.h>
#include <stdio.h>
#include "c2414.h"
#include "CppUTest/TestHarness_c.h"

enum
{
	FLASH_READ, FLASH_WRITE
};

typedef struct Expectation
{
	int kind;
	udword addr;
	uCPUBusType value;
} Expectation;

static Expectation expectations[20];
static int setExpectationCount;
static int getExpectationCount;
static Expectation expected;
static Expectation actual;

char* expect_write_was_read = "Expected Write(0x%x, 0x%x)\n\t\t\tBut was Read(0x%x)";
char* read_wrong_address = "Expected Read(0x%x) returns 0x%x;\n\t\t\tBut was Read(0x%x)";
char* expect_read_was_write = "Expected Read(0x%x) would return 0x%x)\n\t\t\tBut was Write(0x%x, 0x%x)";
char* write_does_not_match = "Expected Write(0x%x, 0x%x)\n\t\t\tBut was Write(0x%x, 0x%x)";

void Reset_FlashRead_and_FlashWrite()
{
	memset(expectations, 0, sizeof(expectations));
	setExpectationCount = 0;
	getExpectationCount = 0;
}

void Expect_FlashWrite(udword addr, uCPUBusType value)
{
	expectations[setExpectationCount].kind = FLASH_WRITE;
	expectations[setExpectationCount].addr = addr;
	expectations[setExpectationCount].value = value;
	setExpectationCount++;
}

void Expect_FlashRead(udword addr, uCPUBusType value)
{
	expectations[setExpectationCount].kind = FLASH_READ;
	expectations[setExpectationCount].addr = addr;
	expectations[setExpectationCount].value = value;
	setExpectationCount++;
}

void assertUnusedExpectation(char* format)
{
	char buffer[100];

	if (getExpectationCount >= setExpectationCount)
	{
		int offset = sprintf(buffer, "R/W %d: No expectations but was ",
				getExpectationCount + 1);
		sprintf(buffer + offset, format, actual.addr, actual.value);
		FAIL_TEXT_C(buffer);
	}
}

static void setExpectedAndActuals(udword addr, uCPUBusType value)
{
	expected.addr = expectations[getExpectationCount].addr;
	expected.value = expectations[getExpectationCount].value;
	actual.addr = addr;
	actual.value = value;
}

static void failExpectation(char* contexFormat)
{
	char buffer[100];
	int offset = sprintf(buffer, "R/W %d: ", getExpectationCount + 1);
	sprintf(buffer + offset, contexFormat, expected.addr, expected.value, actual.addr, actual.value);
	FAIL_TEXT_C(buffer);
}

uCPUBusType FlashRead(udword addr)
{
	setExpectedAndActuals(addr, -1);

	assertUnusedExpectation("Read(0x%x)");

	if (FLASH_READ != expectations[getExpectationCount].kind)
		failExpectation(expect_write_was_read);

	if (expected.addr != addr)
		failExpectation(read_wrong_address);

	return expectations[getExpectationCount++].value;
}

void FlashWrite(udword addr, uCPUBusType value)
{
	setExpectedAndActuals(addr, value);

	assertUnusedExpectation("Write(0x%x, 0x%x)");

	if (FLASH_WRITE != expectations[getExpectationCount].kind)
		failExpectation(expect_write_was_read);

	if (expected.addr != addr || expected.value != value)
		failExpectation(write_does_not_match);

	getExpectationCount++;
}

void Check_FlashWrite_Expectations()
{
	char buffer[100];
	if (getExpectationCount == setExpectationCount)
		return;

	sprintf(buffer, "Expected %d reads/writes but got %d",
			setExpectationCount, getExpectationCount);
	FAIL_TEXT_C(buffer);

}
