//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#ifndef D_MockC2414FlashReadAndWrite_H
#define D_MockC2414FlashReadAndWrite_H

#include "c2414FlashReadAndWrite.h"

void Reset_FlashRead_and_FlashWrite();
void Expect_FlashWrite(udword udAddrOff, uCPUBusType ucVal);
void Expect_FlashRead(udword udAddrOff, uCPUBusType ucVal);
void Check_FlashWrite_Expectations();

#endif
