//- Copyright (c) 2008-2009 James Grenning
//- All rights reserved
//- For use by participants in James' training courses.

#include "CppUTest/TestHarness.h"

extern "C" {
#include "MockC2414ReadAndWrite.h"
}

//START: BetterInitialTest
TEST_GROUP(Flash)
{
    enum  {
        eraseBlock = 0x20,
        writeEraseConfirm = 0xD0,
        blockNumber = 4,
        flashDone = 1<<7,
        flashNotDone = 0,
        vppError = 1<<3,
        commandSequenceError = 1<<4 | 1<<5,
        eraseError = 1<<5,
        writeToProtectedBlock = 1,
        clearStatusWord = 0x50,
    };

    void setup()
    {
        Reset_FlashRead_and_FlashWrite();
    }
    void teardown()
    {
    }
};

TEST(Flash, CheckCfiCommand)
{
    ParameterType p;
    ReturnType result;

    p.ReadCfi.uwCfiFunc = 0x24;

    Expect_FlashWrite(0x0, 0x98);
    Expect_FlashRead(0x10, 'Q');
    Expect_FlashRead(0x11, 'R');
    Expect_FlashRead(0x12, 'Y');
    Expect_FlashRead(p.ReadCfi.uwCfiFunc, 0xAA);
    Expect_FlashWrite(0x0, 0xff);

    result = Flash(ReadCfi, &p);

    LONGS_EQUAL(Flash_Success, result);
    LONGS_EQUAL(0xAA, p.ReadCfi.ucCfiValue);
    Check_FlashWrite_Expectations();
}

TEST(Flash, BlockErase)
{
    ReturnType result;

    Expect_FlashWrite(0x0, 0x50);
    Expect_FlashWrite(0x0, 0x20);
    Expect_FlashWrite(0x0fe000, 0xd0);
    Expect_FlashRead(0x0, flashDone | vppError);
    Expect_FlashWrite(0x0, 0x50);
    Expect_FlashWrite(0x0, 0xff);
    result = FlashBlockErase(1);

    LONGS_EQUAL(Flash_VppInvalid, result);
    Check_FlashWrite_Expectations();
}
