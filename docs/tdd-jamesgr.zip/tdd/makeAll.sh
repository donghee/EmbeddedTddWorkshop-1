#/bin/bash

make -C CppUTest
make -C TddInCppExercises1
make -C TddInCppExercises2
make -C TddInCppSolutions

echo NOTE: "**********************************************"
echo NOTE: "* Use this only for the initial build.       *"
echo NOTE: "* After that cd into the exercises directory.*"
echo NOTE: "**********************************************"

 