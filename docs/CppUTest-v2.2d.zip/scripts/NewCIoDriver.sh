#!/bin/bash
TEMPLATE_DIR=${CPP_U_TEST}/scripts/templates
source ${CPP_U_TEST}/scripts/GenerateSrcFiles.sh ClassNameCIoDriver c NoMock $1 $2

