#Generated file - cleanAll.sh
echo "Running cleanAll for CppUTest v2.2d created on 2010-09-12-14-44"
export CPPUTEST_HOME=$(pwd)
echo "export CPPUTEST_HOME=$(pwd)/"
make cleanEverythingInstall
