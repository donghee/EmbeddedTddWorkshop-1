#include "LedDriver.h"
#include <stdlib.h>
#include <memory.h>

//static local variables


void LedDriver_Create(void)
{
}

void LedDriver_Destroy(void)
{
}


