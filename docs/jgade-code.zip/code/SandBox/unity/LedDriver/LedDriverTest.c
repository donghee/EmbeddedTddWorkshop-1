//- Copyright (c) 2010 James Grenning --- All rights reserved
//- You may use the source code in your own projects, however
//- the source code may not be used to create training material,
//- courses, books, articles, and the like. We make no guarantees
//- that this source code is fit for any purpose.
//- www.renaissancesoftware.net james@renaissancesoftware.net

#include "unity_fixture.h"
#include "LedDriver.h"

#include "unity_fixture.h"

TEST_GROUP(LedDriver)

TEST_SETUP(LedDriver)
{
}

TEST_TEAR_DOWN(LedDriver)
{
}

TEST(LedDriver, StartHere)
{
//    TEST_FAIL("Start here");
}
