#---
# Excerpted from "Test Driven Development for Embedded C",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/jgade for more book information.
#---
#Generated file - makeAll.sh
echo "Running makeAll for CppUTest v2.2c created on 2010-08-10-15-35"
export CPPUTEST_HOME=
export CPPUTEST_ENABLE_EXTENSIONS=Y
make all
make examples
