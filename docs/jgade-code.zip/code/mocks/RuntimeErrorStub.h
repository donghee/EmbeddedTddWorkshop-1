#ifndef D_RuntimeErrorStub_H
#define D_RuntimeErrorStub_H

#include "RuntimeError.h"

void RuntimeErrorStub_Reset();
const char * RuntimeErrorStub_GetLastError();

#endif
