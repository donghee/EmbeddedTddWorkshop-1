#include "common.h"

void RuntimeErrorStub_Reset();
const char * RuntimeErrorStub_GetLastError();
