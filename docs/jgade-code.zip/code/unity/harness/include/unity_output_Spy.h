#ifndef D_unity_output_Spy_H
#define D_unity_output_Spy_H

void UnityOutputCharSpy_Create(int s);
void UnityOutputCharSpy_Destroy();
int UnityOutputCharSpy_OutputChar(int c);
const char * UnityOutputCharSpy_Get();

#endif
